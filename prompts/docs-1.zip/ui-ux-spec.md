# LegalMind Arbitrate - UI/UX设计规范

## 1. 设计愿景

### 1.1 设计目标
创造一个现代、简洁、高级的在线仲裁平台，给用户带来"Aha!"的视觉感受，同时体现法律行业的专业性和权威性。

### 1.2 设计原则
- **现代简约**: 清晰的视觉层次，去除不必要的装饰元素
- **专业可信**: 体现法律服务的严谨性和权威性
- **用户友好**: 直观的操作流程，降低学习成本
- **情感共鸣**: 通过设计传达安全感和信任感
- **创新突破**: 在传统法律界面基础上的创新突破

## 2. 品牌视觉系统

### 2.1 色彩系统
**主色调**:
- **橙色 (Primary Orange)**: `#FF6B35` - 活力、创新、温暖
- **深橙色 (Dark Orange)**: `#E55A2B` - 强调和悬停状态
- **浅橙色 (Light Orange)**: `#FF8A65` - 辅助和背景

**中性色**:
- **纯白 (Pure White)**: `#FFFFFF` - 主背景色
- **浅灰 (Light Gray)**: `#F8F9FA` - 次要背景
- **中灰 (Medium Gray)**: `#6C757D` - 次要文本
- **深灰 (Dark Gray)**: `#343A40` - 主要文本
- **边框灰 (Border Gray)**: `#E9ECEF` - 分割线和边框

**功能色**:
- **成功绿 (Success)**: `#28A745` - 成功状态
- **警告黄 (Warning)**: `#FFC107` - 警告状态
- **错误红 (Error)**: `#DC3545` - 错误状态
- **信息蓝 (Info)**: `#17A2B8` - 信息提示

### 2.2 字体系统
**中文字体**:
- **主字体**: PingFang SC, -apple-system, BlinkMacSystemFont
- **备选字体**: "Helvetica Neue", Arial, "Noto Sans CJK SC", sans-serif

**英文字体**:
- **主字体**: Inter, -apple-system, BlinkMacSystemFont
- **备选字体**: "Segoe UI", Roboto, sans-serif

**字体层级**:
```css
/* 标题层级 */
.text-4xl { font-size: 2.25rem; line-height: 2.5rem; } /* 36px */
.text-3xl { font-size: 1.875rem; line-height: 2.25rem; } /* 30px */
.text-2xl { font-size: 1.5rem; line-height: 2rem; } /* 24px */
.text-xl { font-size: 1.25rem; line-height: 1.75rem; } /* 20px */
.text-lg { font-size: 1.125rem; line-height: 1.75rem; } /* 18px */

/* 正文层级 */
.text-base { font-size: 1rem; line-height: 1.5rem; } /* 16px */
.text-sm { font-size: 0.875rem; line-height: 1.25rem; } /* 14px */
.text-xs { font-size: 0.75rem; line-height: 1rem; } /* 12px */
```

### 2.3 图标系统
- **图标库**: Lucide React
- **风格**: 线性图标，2px描边
- **尺寸**: 16px, 20px, 24px, 32px
- **颜色**: 继承文本颜色或使用主题色

## 3. 布局系统

### 3.1 网格系统
- **容器最大宽度**: 1200px
- **网格列数**: 12列
- **间距**: 16px, 24px, 32px
- **断点**:
  - `sm`: 640px
  - `md`: 768px
  - `lg`: 1024px
  - `xl`: 1280px

### 3.2 间距系统
```css
/* Tailwind CSS间距系统 */
.space-1 { margin/padding: 0.25rem; } /* 4px */
.space-2 { margin/padding: 0.5rem; } /* 8px */
.space-3 { margin/padding: 0.75rem; } /* 12px */
.space-4 { margin/padding: 1rem; } /* 16px */
.space-6 { margin/padding: 1.5rem; } /* 24px */
.space-8 { margin/padding: 2rem; } /* 32px */
.space-12 { margin/padding: 3rem; } /* 48px */
.space-16 { margin/padding: 4rem; } /* 64px */
```

### 3.3 圆角系统
```css
.rounded-none { border-radius: 0; }
.rounded-sm { border-radius: 0.125rem; } /* 2px */
.rounded { border-radius: 0.25rem; } /* 4px */
.rounded-md { border-radius: 0.375rem; } /* 6px */
.rounded-lg { border-radius: 0.5rem; } /* 8px */
.rounded-xl { border-radius: 0.75rem; } /* 12px */
.rounded-full { border-radius: 9999px; }
```

## 4. 组件设计规范

### 4.1 按钮 (Button)
**主要按钮**:
```css
.btn-primary {
  background: #FF6B35;
  color: white;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 500;
  transition: all 0.2s;
}
.btn-primary:hover {
  background: #E55A2B;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(255, 107, 53, 0.3);
}
```

**次要按钮**:
```css
.btn-secondary {
  background: white;
  color: #FF6B35;
  border: 1px solid #FF6B35;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 500;
}
```

### 4.2 卡片 (Card)
```css
.card {
  background: white;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #E9ECEF;
  padding: 24px;
  transition: all 0.2s;
}
.card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}
```

### 4.3 表单元素
**输入框**:
```css
.input {
  border: 1px solid #E9ECEF;
  border-radius: 8px;
  padding: 12px 16px;
  font-size: 16px;
  transition: all 0.2s;
}
.input:focus {
  border-color: #FF6B35;
  box-shadow: 0 0 0 3px rgba(255, 107, 53, 0.1);
}
```

## 5. 页面布局规范

### 5.1 导航栏
- **高度**: 64px
- **背景**: 白色，底部1px边框
- **Logo**: 左侧，高度32px
- **导航菜单**: 中间，水平排列
- **用户菜单**: 右侧，头像+下拉菜单

### 5.2 侧边栏
- **宽度**: 280px (展开), 64px (收起)
- **背景**: 白色
- **菜单项**: 48px高度，8px圆角
- **图标**: 20px尺寸

### 5.3 主内容区
- **背景**: #F8F9FA
- **内边距**: 24px
- **卡片间距**: 24px
- **最大宽度**: 1200px

## 6. 数字法庭界面设计

### 6.1 整体布局
```
┌─────────────────────────────────────────────────────────────┐
│                        顶部控制栏                            │
├─────────────────┬─────────────────┬─────────────────────────┤
│                 │                 │                         │
│   参与者视频    │   主发言人      │      实时转录面板        │
│     网格        │     视图        │                         │
│                 │                 │                         │
├─────────────────┼─────────────────┼─────────────────────────┤
│                 │                 │                         │
│   证据展示      │   控制面板      │      聊天/私密沟通       │
│     面板        │                 │                         │
│                 │                 │                         │
└─────────────────┴─────────────────┴─────────────────────────┘
```

### 6.2 视频面板设计
- **主发言人视图**: 16:9比例，最小480x270px
- **参与者网格**: 每个视频框16:9比例，显示姓名和角色标识
- **视频控制**: 静音、摄像头开关、举手按钮

### 6.3 交互元素
- **举手按钮**: 橙色高亮，动画效果
- **发言状态**: 绿色边框指示当前发言人
- **网络状态**: 信号强度指示器
- **录制状态**: 红色录制指示灯

## 7. 响应式设计

### 7.1 桌面端 (≥1024px)
- 完整的多面板布局
- 侧边栏展开显示
- 丰富的交互功能

### 7.2 平板端 (768px-1023px)
- 简化的布局结构
- 可折叠的侧边栏
- 触摸友好的控件

### 7.3 移动端 (<768px)
- 单列布局
- 底部导航栏
- 全屏视频模式

## 8. 动画和过渡

### 8.1 基础过渡
```css
.transition-base {
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}
```

### 8.2 悬停效果
- **按钮**: 轻微上移 + 阴影增强
- **卡片**: 上移2px + 阴影扩散
- **链接**: 颜色渐变

### 8.3 加载动画
- **骨架屏**: 灰色占位符，脉冲动画
- **加载指示器**: 橙色旋转圆环
- **进度条**: 橙色渐变填充

## 9. 可访问性设计

### 9.1 颜色对比
- 文本与背景对比度 ≥ 4.5:1
- 大文本对比度 ≥ 3:1
- 非文本元素对比度 ≥ 3:1

### 9.2 键盘导航
- 所有交互元素支持Tab导航
- 清晰的焦点指示器
- 合理的Tab顺序

### 9.3 屏幕阅读器
- 语义化HTML标签
- 适当的ARIA标签
- 图片alt文本

## 10. 设计系统实现

### 10.1 Tailwind配置
```javascript
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#FFF4F1',
          500: '#FF6B35',
          600: '#E55A2B',
          700: '#CC4A1F',
        }
      },
      fontFamily: {
        sans: ['Inter', 'PingFang SC', 'sans-serif'],
      }
    }
  }
}
```

### 10.2 组件库结构
```
components/
├── ui/                 # 基础UI组件
│   ├── Button.tsx
│   ├── Card.tsx
│   ├── Input.tsx
│   └── ...
├── layout/            # 布局组件
│   ├── Header.tsx
│   ├── Sidebar.tsx
│   └── ...
└── features/          # 功能组件
    ├── VideoCall/
    ├── CaseManagement/
    └── ...
```

## 11. 设计质量保证

### 11.1 设计审查清单
- [ ] 符合品牌视觉规范
- [ ] 响应式设计完整
- [ ] 可访问性标准达标
- [ ] 交互反馈及时
- [ ] 加载状态处理

### 11.2 用户测试
- 可用性测试
- A/B测试
- 用户反馈收集
- 迭代优化

## 12. 设计资源

### 12.1 设计工具
- **设计**: Figma
- **原型**: Figma/Framer
- **图标**: Lucide, Heroicons
- **插图**: 自定义插图库

### 12.2 设计交付
- 设计稿 (Figma)
- 组件库文档
- 交互原型
- 设计规范文档


## 13. 在线庭审交互规范（原型 v0.1）

### 13.1 庭前等候室（/hearings/[id]/waiting）
- 设备检测：自动检测摄像头/麦克风/网络（视觉进度与通过标识），失败给出引导
- 身份核验：一键核验占位（后续接OCR/活体/实名比对）；通过后显示绿色状态
- 庭审须知：弹窗阅读并勾选同意（作为进入庭审的门槛）
- 材料预览：个人证据清单只读卡片列表（PDF/图片/视频占位）
- 私聊：与本方代理/书记员的即时消息侧栏（频道切换、发送、时间戳）
- 进入条件：设备检测+身份核验+须知同意 全部完成后高亮“进入庭审”

### 13.2 直播庭审（/hearings/[id]/live）增强
- 顶部工具条：录制状态、案件号与当前时间；快捷按钮：证据/笔录/身份核对/离开
- 主画面：当前发言人视图（语音激励占位）+ 参与者缩略条
- 底部控制：麦克风/摄像头/屏幕共享/证据/AI笔录/举手/聊天/参与者
- 主持控制：
  - 全体静音、指定发言
  - 举手队列（授予下一个/逐项授予）
  - 身份核对（流程入口）
  - 证人管理（邀请入庭/请出）
- 证据面板（左侧抽屉）：列表+预览占位（PDF/图片/视频）+标注工具（高亮/橡皮）+缩放
- AI笔录面板（右侧抽屉）：实时滚动记录+“勘误申请”占位
- 身份核对流程：依次高亮参与者缩略与右侧列表项，并在已核对者姓名旁显示“✓”
- 主题：遵循系统主题（明/暗）与 LegalMind 品牌色（橙+白）的一致性

### 13.3 无障碍与一致性
- 所有关键按钮提供 title/aria-label 与焦点可见性
- 控件尺寸与间距遵循 8pt 网格；移动端优先
- 交互一致：证据/笔录面板均使用抽屉式呈现；控制按钮风格一致
