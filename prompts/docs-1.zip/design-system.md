# LegalMind Arbitration - 设计系统规范

## 设计哲学

LegalMind仲裁平台遵循四大核心设计哲学：

1. **Trust through Clarity** - 透明直观的UI建立信任
2. **Efficiency through Intelligence** - AI功能提升效率
3. **Authority through Design** - 专业设计体现权威
4. **Innovation within Bounds** - 约束内的创新

## 品牌色彩系统

### 主色调 - 橙色系
- **Primary**: `#FF6B35` - 主要品牌色，用于CTA按钮、链接、重要元素
- **Primary-50**: `#FFF4F1` - 最浅色调，用于背景
- **Primary-100**: `#FFE6DC` - 浅色调，用于悬停状态
- **Primary-500**: `#FF6B35` - 标准色调
- **Primary-600**: `#E55A2B` - 深色调，用于悬停状态
- **Primary-900**: `#992A07` - 最深色调，用于文字

### 中性色系
- **Background**: `#FFFFFF` - 主背景色
- **Foreground**: `#1A1A1A` - 主文字色
- **Muted**: `#F8F9FA` - 次要背景色
- **Border**: `#E9ECEF` - 边框色

### 功能色系
- **Success**: `#28A745` - 成功状态
- **Warning**: `#FFC107` - 警告状态
- **Destructive**: `#DC3545` - 错误/危险状态
- **Info**: `#17A2B8` - 信息状态

## 组件规范

### 按钮 (Button)

#### 变体类型
1. **Default** - 主要操作按钮
   - 背景：橙色渐变 `from-orange-500 to-orange-600`
   - 文字：白色
   - 阴影：品牌阴影 `shadow-brand`
   - 悬停：缩放 `scale-105` + 阴影增强

2. **Outline** - 次要操作按钮
   - 边框：灰色 `border-gray-200`
   - 背景：白色
   - 悬停：橙色背景 + 白色文字

3. **Ghost** - 最轻量的按钮
   - 背景：透明
   - 悬停：橙色背景 `bg-orange-50`

#### 尺寸规格
- **Small**: `h-8 px-3` - 紧凑空间使用
- **Default**: `h-9 px-4` - 标准尺寸
- **Large**: `h-12 px-8` - 重要操作使用

### 卡片 (Card)

#### 基础样式
- 背景：白色 `bg-white`
- 边框：浅灰色 `border-gray-200`
- 圆角：`rounded-xl` (12px)
- 阴影：卡片阴影 `shadow-card`
- 悬停：向上移动 `translateY(-4px)` + 阴影增强

#### 组件结构
- **CardHeader** - 标题区域，包含标题和描述
- **CardContent** - 主要内容区域
- **CardFooter** - 底部操作区域
- **CardAction** - 右上角操作按钮

### 输入框 (Input)

#### 基础样式
- 背景：浅灰色 `bg-gray-50`
- 边框：2px 灰色边框
- 圆角：`rounded-lg` (8px)
- 内边距：`px-4 py-3`

#### 状态样式
- **Focus**: 橙色边框 + 橙色阴影
- **Hover**: 边框颜色变浅
- **Error**: 红色边框
- **Disabled**: 灰色背景 + 降低透明度

## 动画系统

### 过渡动画
- **标准过渡**: `transition-all duration-300`
- **缓动函数**: `cubic-bezier(0.4, 0, 0.2, 1)`

### 悬停效果
- **hover-lift**: 向上移动 4px + 阴影增强
- **hover-glow**: 橙色光晕效果
- **hover-scale**: 轻微缩放 `scale-105`

### 关键帧动画
- **fadeIn**: 淡入效果 (0.5s)
- **slideUp**: 向上滑入 (0.5s)
- **scaleIn**: 缩放进入 (0.3s)
- **bounceIn**: 弹跳进入 (0.6s)

## 阴影系统

### 品牌阴影
- **shadow-brand**: `0 4px 12px rgba(255, 107, 53, 0.15)`
- **shadow-brand-lg**: `0 8px 24px rgba(255, 107, 53, 0.2)`

### 卡片阴影
- **shadow-card**: `0 2px 8px rgba(0, 0, 0, 0.08)`
- **shadow-card-hover**: `0 4px 16px rgba(0, 0, 0, 0.12)`

## 间距系统

### 标准间距
- **xs**: `0.25rem` (4px)
- **sm**: `0.5rem` (8px)
- **md**: `1rem` (16px)
- **lg**: `1.5rem` (24px)
- **xl**: `2rem` (32px)
- **2xl**: `3rem` (48px)

### 组件间距
- 卡片内边距：`p-6` (24px)
- 按钮内边距：`px-4 py-2` (16px 8px)
- 表单元素间距：`space-y-4` (16px)

## 字体系统

### 字体族
- **主字体**: Inter, PingFang SC, -apple-system, BlinkMacSystemFont
- **等宽字体**: 'SF Mono', Monaco, 'Cascadia Code', monospace

### 字体大小
- **xs**: `0.75rem` (12px) - 辅助文字
- **sm**: `0.875rem` (14px) - 正文
- **base**: `1rem` (16px) - 标准文字
- **lg**: `1.125rem` (18px) - 小标题
- **xl**: `1.25rem` (20px) - 标题
- **2xl**: `1.5rem` (24px) - 大标题

### 字重
- **normal**: 400 - 正文
- **medium**: 500 - 次要标题
- **semibold**: 600 - 重要文字
- **bold**: 700 - 主标题

## 响应式设计

### 断点系统
- **sm**: `640px` - 小屏幕
- **md**: `768px` - 平板
- **lg**: `1024px` - 桌面
- **xl**: `1280px` - 大屏幕

### 布局原则
- 移动优先设计
- 弹性布局使用Flexbox和Grid
- 内容优先，确保核心功能在小屏幕可用
- 渐进增强，大屏幕提供更丰富的交互

## 可访问性

### 颜色对比
- 所有文字与背景对比度 ≥ 4.5:1
- 重要信息对比度 ≥ 7:1

### 焦点管理
- 明确的焦点指示器
- 逻辑的Tab键顺序
- 键盘导航支持

### 语义化
- 正确使用HTML语义标签
- 适当的ARIA标签
- 屏幕阅读器友好

## 使用指南

### 组件复用
1. 优先使用设计系统中的组件
2. 需要自定义时，继承基础样式
3. 保持视觉一致性
4. 遵循交互模式

### 颜色使用
1. 主色调用于重要操作和品牌元素
2. 中性色用于文字和背景
3. 功能色用于状态指示
4. 避免过度使用鲜艳颜色

### 动画使用
1. 微交互增强用户体验
2. 保持动画时长适中（200-500ms）
3. 使用一致的缓动函数
4. 避免过度动画影响性能
