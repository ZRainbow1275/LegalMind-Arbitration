# LegalMind Arbitrate - 数据流设计文档

## 1. 数据架构概览

### 1.1 整体数据流
```
用户界面 ↔ 状态管理 ↔ API层 ↔ 业务逻辑 ↔ 数据持久化
   ↓           ↓        ↓        ↓          ↓
 React     Zustand   Next.js   NestJS   PostgreSQL
Components  Store   API Routes Services   + Redis
```

### 1.2 数据分层
- **表现层**: React组件和UI状态
- **状态层**: Zustand全局状态管理
- **API层**: Next.js API Routes和外部API
- **业务层**: 业务逻辑和数据处理
- **持久层**: PostgreSQL数据库和Redis缓存

## 2. 核心数据实体

### 2.1 用户相关实体
```typescript
// 用户基础信息
interface User {
  id: string;
  email: string;
  phone: string;
  userType: 'individual' | 'enterprise';
  status: 'active' | 'inactive' | 'suspended';
  createdAt: Date;
  updatedAt: Date;
}

// 个人用户认证信息
interface IndividualProfile {
  userId: string;
  realName: string;
  idNumber: string;
  idCardImages: string[];
  faceVerificationData: string;
  verificationStatus: 'pending' | 'verified' | 'rejected';
}

// 企业用户认证信息
interface EnterpriseProfile {
  userId: string;
  companyName: string;
  businessLicense: string;
  legalRepresentative: string;
  legalRepIdNumber: string;
  verificationDocuments: string[];
  verificationStatus: 'pending' | 'verified' | 'rejected';
}
```

### 2.2 案件相关实体
```typescript
// 仲裁案件
interface ArbitrationCase {
  id: string;
  caseNumber: string;
  applicantId: string;
  respondentId: string;
  caseType: string;
  disputeAmount: number;
  status: CaseStatus;
  arbitrationAgreement: string;
  applicationForm: string;
  evidenceList: Evidence[];
  createdAt: Date;
  updatedAt: Date;
}

// 案件状态枚举
enum CaseStatus {
  DRAFT = 'draft',
  SUBMITTED = 'submitted',
  ACCEPTED = 'accepted',
  PAYMENT_PENDING = 'payment_pending',
  TRIBUNAL_FORMATION = 'tribunal_formation',
  PRE_HEARING = 'pre_hearing',
  HEARING_SCHEDULED = 'hearing_scheduled',
  HEARING_IN_PROGRESS = 'hearing_in_progress',
  DELIBERATION = 'deliberation',
  AWARD_ISSUED = 'award_issued',
  COMPLETED = 'completed',
  TERMINATED = 'terminated'
}

// 证据材料
interface Evidence {
  id: string;
  caseId: string;
  uploaderId: string;
  fileName: string;
  fileUrl: string;
  fileType: string;
  fileSize: number;
  description: string;
  category: 'contract' | 'correspondence' | 'financial' | 'other';
  uploadedAt: Date;
}
```

### 2.3 仲裁庭相关实体
```typescript
// 仲裁员
interface Arbitrator {
  id: string;
  name: string;
  title: string;
  specialties: string[];
  experience: number;
  qualifications: string[];
  availability: boolean;
  rating: number;
  profileImage: string;
  biography: string;
}

// 仲裁庭
interface ArbitrationTribunal {
  id: string;
  caseId: string;
  presiding: string; // 首席仲裁员ID
  arbitrators: string[]; // 仲裁员ID列表
  status: 'forming' | 'confirmed' | 'active' | 'dissolved';
  formedAt: Date;
}

// 回避申请
interface ChallengeApplication {
  id: string;
  caseId: string;
  arbitratorId: string;
  applicantId: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: Date;
  decidedAt?: Date;
}
```

### 2.4 庭审相关实体
```typescript
// 庭审会话
interface HearingSession {
  id: string;
  caseId: string;
  sessionNumber: number;
  scheduledAt: Date;
  startedAt?: Date;
  endedAt?: Date;
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
  participants: HearingParticipant[];
  recordingUrl?: string;
  transcriptUrl?: string;
}

// 庭审参与者
interface HearingParticipant {
  id: string;
  sessionId: string;
  userId: string;
  role: 'applicant' | 'respondent' | 'arbitrator' | 'witness' | 'observer';
  joinedAt?: Date;
  leftAt?: Date;
  connectionStatus: 'connected' | 'disconnected' | 'reconnecting';
}

// 实时转录
interface TranscriptEntry {
  id: string;
  sessionId: string;
  speakerId: string;
  content: string;
  timestamp: Date;
  confidence: number;
}
```

## 3. 数据流模式

### 3.1 用户认证流程
```mermaid
sequenceDiagram
    participant U as User
    participant UI as Frontend
    participant API as API Layer
    participant Auth as Auth Service
    participant DB as Database

    U->>UI: 提交认证信息
    UI->>API: POST /api/auth/verify
    API->>Auth: 调用OCR服务
    Auth->>API: 返回识别结果
    API->>DB: 保存认证数据
    DB->>API: 确认保存
    API->>UI: 返回认证状态
    UI->>U: 显示认证结果
```

### 3.2 案件申请流程
```mermaid
sequenceDiagram
    participant U as User
    participant UI as Frontend
    participant Store as Zustand Store
    participant API as API Layer
    participant DB as Database

    U->>UI: 填写申请表单
    UI->>Store: 更新表单状态
    U->>UI: 上传证据文件
    UI->>API: POST /api/upload
    API->>DB: 保存文件信息
    U->>UI: 提交申请
    UI->>API: POST /api/cases
    API->>DB: 创建案件记录
    DB->>API: 返回案件ID
    API->>UI: 返回创建结果
    UI->>Store: 更新案件状态
```

### 3.3 在线庭审数据流
```mermaid
sequenceDiagram
    participant P as Participant
    participant UI as Frontend
    participant WS as WebSocket
    participant Media as Media Server
    participant API as API Layer
    participant DB as Database

    P->>UI: 加入庭审
    UI->>WS: 连接WebSocket
    UI->>Media: 建立WebRTC连接
    P->>UI: 发言
    UI->>Media: 传输音视频流
    Media->>WS: 广播给其他参与者
    WS->>API: 发送转录请求
    API->>DB: 保存转录记录
    P->>UI: 展示证据
    UI->>WS: 广播证据信息
    WS->>UI: 同步给其他参与者
```

## 4. 状态管理设计

### 4.1 Zustand Store结构
```typescript
interface AppState {
  // 用户状态
  user: {
    currentUser: User | null;
    profile: IndividualProfile | EnterpriseProfile | null;
    isAuthenticated: boolean;
    loading: boolean;
  };

  // 案件状态
  cases: {
    currentCase: ArbitrationCase | null;
    caseList: ArbitrationCase[];
    loading: boolean;
    filters: CaseFilters;
  };

  // 庭审状态
  hearing: {
    currentSession: HearingSession | null;
    participants: HearingParticipant[];
    transcript: TranscriptEntry[];
    connectionStatus: 'connected' | 'disconnected' | 'reconnecting';
    mediaDevices: MediaDeviceInfo[];
  };

  // UI状态
  ui: {
    sidebarCollapsed: boolean;
    currentModal: string | null;
    notifications: Notification[];
    theme: 'light' | 'dark';
  };
}
```

### 4.2 状态更新模式
```typescript
// 异步状态更新
const useCaseStore = create<CaseState>((set, get) => ({
  cases: [],
  loading: false,
  
  fetchCases: async () => {
    set({ loading: true });
    try {
      const cases = await api.getCases();
      set({ cases, loading: false });
    } catch (error) {
      set({ loading: false });
      // 错误处理
    }
  },

  updateCase: (caseId: string, updates: Partial<ArbitrationCase>) => {
    set(state => ({
      cases: state.cases.map(case => 
        case.id === caseId ? { ...case, ...updates } : case
      )
    }));
  }
}));
```

## 5. API设计

### 5.1 RESTful API结构
```typescript
// 用户相关API
GET    /api/users/profile          // 获取用户资料
PUT    /api/users/profile          // 更新用户资料
POST   /api/users/verify           // 提交实名认证

// 案件相关API
GET    /api/cases                  // 获取案件列表
POST   /api/cases                  // 创建新案件
GET    /api/cases/:id              // 获取案件详情
PUT    /api/cases/:id              // 更新案件信息
DELETE /api/cases/:id              // 删除案件

// 文件上传API
POST   /api/upload                 // 上传文件
GET    /api/files/:id              // 获取文件
DELETE /api/files/:id              // 删除文件

// 庭审相关API
GET    /api/hearings/:caseId       // 获取庭审信息
POST   /api/hearings               // 创建庭审会话
PUT    /api/hearings/:id/join      // 加入庭审
PUT    /api/hearings/:id/leave     // 离开庭审
```

### 5.2 WebSocket事件
```typescript
// 庭审相关事件
interface HearingEvents {
  // 连接管理
  'hearing:join': { sessionId: string; userId: string };
  'hearing:leave': { sessionId: string; userId: string };
  
  // 媒体控制
  'media:mute': { userId: string; muted: boolean };
  'media:video': { userId: string; enabled: boolean };
  'media:screen-share': { userId: string; sharing: boolean };
  
  // 交互功能
  'interaction:raise-hand': { userId: string };
  'interaction:lower-hand': { userId: string };
  'interaction:chat': { userId: string; message: string };
  
  // 证据展示
  'evidence:show': { evidenceId: string; userId: string };
  'evidence:annotate': { evidenceId: string; annotation: Annotation };
  
  // 转录相关
  'transcript:update': { entry: TranscriptEntry };
  'transcript:correction': { entryId: string; correction: string };
}
```

## 6. 数据缓存策略

### 6.1 Redis缓存设计
```typescript
// 缓存键命名规范
const CACHE_KEYS = {
  USER_PROFILE: (userId: string) => `user:profile:${userId}`,
  CASE_DETAILS: (caseId: string) => `case:details:${caseId}`,
  ARBITRATOR_LIST: 'arbitrators:list',
  HEARING_SESSION: (sessionId: string) => `hearing:session:${sessionId}`,
  TRANSCRIPT: (sessionId: string) => `transcript:${sessionId}`,
};

// 缓存过期时间
const CACHE_TTL = {
  USER_PROFILE: 3600,      // 1小时
  CASE_DETAILS: 1800,      // 30分钟
  ARBITRATOR_LIST: 7200,   // 2小时
  HEARING_SESSION: 300,    // 5分钟
  TRANSCRIPT: 86400,       // 24小时
};
```

### 6.2 前端缓存策略
```typescript
// TanStack Query配置
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,     // 5分钟
      cacheTime: 10 * 60 * 1000,    // 10分钟
      retry: 3,
      refetchOnWindowFocus: false,
    },
  },
});

// 查询键工厂
export const queryKeys = {
  cases: {
    all: ['cases'] as const,
    lists: () => [...queryKeys.cases.all, 'list'] as const,
    list: (filters: CaseFilters) => [...queryKeys.cases.lists(), filters] as const,
    details: () => [...queryKeys.cases.all, 'detail'] as const,
    detail: (id: string) => [...queryKeys.cases.details(), id] as const,
  },
  arbitrators: {
    all: ['arbitrators'] as const,
    available: () => [...queryKeys.arbitrators.all, 'available'] as const,
  },
};
```

## 7. 数据同步机制

### 7.1 实时数据同步
```typescript
// WebSocket连接管理
class WebSocketManager {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;

  connect(sessionId: string) {
    this.ws = new WebSocket(`ws://localhost:3001/hearing/${sessionId}`);
    
    this.ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      this.handleMessage(data);
    };

    this.ws.onclose = () => {
      this.handleReconnect();
    };
  }

  private handleMessage(data: any) {
    switch (data.type) {
      case 'participant:joined':
        hearingStore.addParticipant(data.participant);
        break;
      case 'transcript:update':
        hearingStore.addTranscriptEntry(data.entry);
        break;
      // 其他事件处理
    }
  }
}
```

### 7.2 数据一致性保证
```typescript
// 乐观更新模式
const updateCaseMutation = useMutation({
  mutationFn: (updates: Partial<ArbitrationCase>) => 
    api.updateCase(caseId, updates),
  
  onMutate: async (updates) => {
    // 取消正在进行的查询
    await queryClient.cancelQueries({ queryKey: queryKeys.cases.detail(caseId) });
    
    // 获取当前数据快照
    const previousCase = queryClient.getQueryData(queryKeys.cases.detail(caseId));
    
    // 乐观更新
    queryClient.setQueryData(queryKeys.cases.detail(caseId), (old: ArbitrationCase) => ({
      ...old,
      ...updates,
    }));
    
    return { previousCase };
  },
  
  onError: (err, updates, context) => {
    // 回滚到之前的状态
    if (context?.previousCase) {
      queryClient.setQueryData(queryKeys.cases.detail(caseId), context.previousCase);
    }
  },
  
  onSettled: () => {
    // 重新获取数据确保一致性
    queryClient.invalidateQueries({ queryKey: queryKeys.cases.detail(caseId) });
  },
});
```

## 8. 数据安全和隐私

### 8.1 数据加密
```typescript
// 敏感数据加密
interface EncryptedField {
  encrypted: string;
  iv: string;
  tag: string;
}

// 客户端加密工具
class DataEncryption {
  static async encrypt(data: string, key: CryptoKey): Promise<EncryptedField> {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encodedData = new TextEncoder().encode(data);
    
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      encodedData
    );
    
    return {
      encrypted: arrayBufferToBase64(encrypted),
      iv: arrayBufferToBase64(iv),
      tag: '', // GCM模式包含在encrypted中
    };
  }
}
```

### 8.2 访问控制
```typescript
// 基于角色的访问控制
interface AccessControl {
  userId: string;
  role: UserRole;
  permissions: Permission[];
  caseAccess: CaseAccess[];
}

enum Permission {
  READ_CASE = 'read:case',
  WRITE_CASE = 'write:case',
  DELETE_CASE = 'delete:case',
  MANAGE_HEARING = 'manage:hearing',
  VIEW_TRANSCRIPT = 'view:transcript',
}

// 权限检查中间件
const checkPermission = (permission: Permission) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = req.user as User;
    if (hasPermission(user, permission)) {
      next();
    } else {
      res.status(403).json({ error: 'Insufficient permissions' });
    }
  };
};
```

## 9. 数据备份和恢复

### 9.1 数据备份策略
```sql
-- 自动备份脚本
-- 每日全量备份
pg_dump -h localhost -U postgres -d legalmind_arbitrate > backup_$(date +%Y%m%d).sql

-- 每小时增量备份
pg_basebackup -h localhost -U postgres -D /backup/incremental/$(date +%Y%m%d_%H)
```

### 9.2 数据恢复流程
```typescript
// 数据恢复服务
class DataRecoveryService {
  async recoverCase(caseId: string, timestamp: Date): Promise<ArbitrationCase> {
    // 从备份中恢复案件数据
    const backupData = await this.getBackupData(timestamp);
    const caseData = backupData.cases.find(c => c.id === caseId);
    
    if (!caseData) {
      throw new Error('Case not found in backup');
    }
    
    // 恢复到数据库
    await this.restoreCaseData(caseData);
    return caseData;
  }
}
```

## 10. 性能优化

### 10.1 数据库优化
```sql
-- 索引优化
CREATE INDEX idx_cases_status ON arbitration_cases(status);
CREATE INDEX idx_cases_applicant ON arbitration_cases(applicant_id);
CREATE INDEX idx_evidence_case ON evidence(case_id);
CREATE INDEX idx_transcript_session ON transcript_entries(session_id, timestamp);

-- 分区表设计
CREATE TABLE transcript_entries_2024 PARTITION OF transcript_entries
FOR VALUES FROM ('2024-01-01') TO ('2025-01-01');
```

### 10.2 查询优化
```typescript
// 分页查询优化
interface PaginationOptions {
  page: number;
  limit: number;
  cursor?: string;
}

const getCasesWithPagination = async (options: PaginationOptions) => {
  const { page, limit, cursor } = options;
  
  // 使用游标分页提高性能
  const query = cursor 
    ? `SELECT * FROM cases WHERE id > $1 ORDER BY id LIMIT $2`
    : `SELECT * FROM cases ORDER BY id LIMIT $1 OFFSET $2`;
    
  const params = cursor 
    ? [cursor, limit]
    : [limit, (page - 1) * limit];
    
  return await db.query(query, params);
};
```
