# LegalMind 组件设计指南

## 概述

本文档定义了 LegalMind 仲裁平台的组件设计标准，确保整个系统的一致性和可维护性。

## 组件分类体系

### 1. 原子组件 (Atoms)

最基础的UI元素，不可再分割的组件。

#### Button 组件
```typescript
interface ButtonProps {
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  className?: string;
  disabled?: boolean;
  loading?: boolean;
  children: React.ReactNode;
}
```

**设计原则**:
- 支持多种视觉变体
- 包含加载状态
- 支持图标按钮
- 具备无障碍属性

#### Input 组件
```typescript
interface InputProps {
  type?: 'text' | 'email' | 'password' | 'number' | 'tel' | 'url';
  placeholder?: string;
  disabled?: boolean;
  error?: boolean;
  helperText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}
```

**设计原则**:
- 支持多种输入类型
- 包含错误状态显示
- 支持图标装饰
- 提供辅助文本

#### Badge 组件
```typescript
interface BadgeProps {
  variant?: 'default' | 'secondary' | 'destructive' | 'outline';
  size?: 'sm' | 'default' | 'lg';
  children: React.ReactNode;
}
```

**设计原则**:
- 用于状态标识
- 支持多种颜色主题
- 大小可调节

### 2. 分子组件 (Molecules)

由原子组件组合而成的功能单元。

#### SearchBox 组件
```typescript
interface SearchBoxProps {
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  onSearch?: (value: string) => void;
  loading?: boolean;
  suggestions?: string[];
}
```

**组成元素**:
- Input (输入框)
- Button (搜索按钮)
- Icon (搜索图标)

#### FormField 组件
```typescript
interface FormFieldProps {
  label: string;
  required?: boolean;
  error?: string;
  helperText?: string;
  children: React.ReactNode;
}
```

**组成元素**:
- Label (标签)
- Input/Select/Textarea (输入控件)
- ErrorMessage (错误信息)
- HelperText (帮助文本)

#### StatusCard 组件
```typescript
interface StatusCardProps {
  title: string;
  value: string | number;
  icon?: React.ReactNode;
  trend?: {
    value: number;
    direction: 'up' | 'down';
    label: string;
  };
  color?: 'blue' | 'green' | 'orange' | 'red';
}
```

**组成元素**:
- Card (容器)
- Icon (状态图标)
- Typography (文本)
- Badge (趋势标识)

### 3. 有机体组件 (Organisms)

复杂的功能组件，包含完整的业务逻辑。

#### DataTable 组件
```typescript
interface DataTableProps<T> {
  data: T[];
  columns: ColumnDef<T>[];
  loading?: boolean;
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    onPageChange: (page: number) => void;
  };
  sorting?: {
    field: keyof T;
    direction: 'asc' | 'desc';
    onSort: (field: keyof T, direction: 'asc' | 'desc') => void;
  };
  filtering?: {
    filters: Record<string, any>;
    onFilter: (filters: Record<string, any>) => void;
  };
}
```

**功能特性**:
- 数据展示和排序
- 分页控制
- 筛选功能
- 加载状态
- 响应式设计

#### NavigationSidebar 组件
```typescript
interface NavigationSidebarProps {
  items: NavigationItem[];
  currentPath: string;
  collapsed?: boolean;
  onToggle?: () => void;
  user?: {
    name: string;
    avatar?: string;
    role: string;
  };
}
```

**功能特性**:
- 导航菜单
- 用户信息显示
- 折叠/展开控制
- 当前页面高亮
- 角色权限控制

#### CaseCard 组件
```typescript
interface CaseCardProps {
  case: {
    id: string;
    title: string;
    caseNumber: string;
    status: CaseStatus;
    type: CaseType;
    amount: number;
    createdAt: string;
    deadline?: string;
    parties: string[];
    progress: number;
  };
  onView?: (id: string) => void;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}
```

**功能特性**:
- 案件信息展示
- 状态可视化
- 进度条显示
- 操作按钮组
- 悬停效果

### 4. 模板组件 (Templates)

定义页面布局结构的组件。

#### PageLayout 组件
```typescript
interface PageLayoutProps {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  breadcrumbs?: BreadcrumbItem[];
  children: React.ReactNode;
  sidebar?: React.ReactNode;
}
```

**布局结构**:
```
┌─────────────────────────────────┐
│ Header (title, actions)         │
├─────────────────────────────────┤
│ Breadcrumbs                     │
├─────────┬───────────────────────┤
│ Sidebar │ Main Content          │
│         │                       │
│         │                       │
└─────────┴───────────────────────┘
```

#### FormLayout 组件
```typescript
interface FormLayoutProps {
  title: string;
  description?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
  loading?: boolean;
}
```

**布局特性**:
- 表单标题和描述
- 响应式表单布局
- 操作按钮区域
- 加载状态覆盖

## 组件开发规范

### 1. 文件结构

```
components/
├── ui/                 # 基础UI组件
│   ├── button.tsx
│   ├── input.tsx
│   └── index.ts       # 导出文件
├── forms/             # 表单相关组件
│   ├── search-box.tsx
│   ├── form-field.tsx
│   └── index.ts
├── layout/            # 布局组件
│   ├── page-layout.tsx
│   ├── sidebar.tsx
│   └── index.ts
└── [feature]/         # 功能特定组件
    ├── case-card.tsx
    ├── case-list.tsx
    └── index.ts
```

### 2. 组件模板

```typescript
// components/ui/example-component.tsx
'use client';

import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

// 样式变体定义
const exampleVariants = cva(
  "base-styles", // 基础样式
  {
    variants: {
      variant: {
        default: "default-styles",
        secondary: "secondary-styles",
      },
      size: {
        sm: "small-styles",
        default: "default-size-styles",
        lg: "large-styles",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

// Props 接口定义
interface ExampleComponentProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof exampleVariants> {
  // 自定义 props
  customProp?: string;
}

// 组件实现
const ExampleComponent = React.forwardRef<
  HTMLDivElement,
  ExampleComponentProps
>(({ className, variant, size, customProp, ...props }, ref) => {
  return (
    <div
      className={cn(exampleVariants({ variant, size, className }))}
      ref={ref}
      {...props}
    >
      {/* 组件内容 */}
    </div>
  );
});

ExampleComponent.displayName = "ExampleComponent";

export { ExampleComponent, exampleVariants };
export type { ExampleComponentProps };
```

### 3. 样式规范

#### 使用 CVA (Class Variance Authority)
```typescript
const buttonVariants = cva(
  // 基础样式
  "inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "underline-offset-4 hover:underline text-primary",
      },
      size: {
        default: "h-10 py-2 px-4",
        sm: "h-9 px-3 rounded-md",
        lg: "h-11 px-8 rounded-md",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);
```

#### Tailwind CSS 类名规范
- **布局**: `flex`, `grid`, `absolute`, `relative`
- **间距**: `p-*`, `m-*`, `gap-*`, `space-*`
- **尺寸**: `w-*`, `h-*`, `max-w-*`, `min-h-*`
- **颜色**: 使用语义化颜色变量
- **响应式**: `sm:*`, `md:*`, `lg:*`, `xl:*`

### 4. 状态管理

#### 组件内部状态
```typescript
const [isOpen, setIsOpen] = useState(false);
const [loading, setLoading] = useState(false);
const [error, setError] = useState<string | null>(null);
```

#### 全局状态 (Zustand)
```typescript
// 在组件中使用
const { data, loading, error, fetchData } = useFeatureStore();

useEffect(() => {
  fetchData();
}, [fetchData]);
```

### 5. 事件处理

#### 事件命名规范
- `onXxx`: 事件回调 (如 `onClick`, `onChange`)
- `handleXxx`: 内部事件处理函数 (如 `handleSubmit`, `handleChange`)

#### 事件处理示例
```typescript
const handleSubmit = async (event: React.FormEvent) => {
  event.preventDefault();
  setLoading(true);
  
  try {
    await onSubmit?.(formData);
    setError(null);
  } catch (err) {
    setError(err instanceof Error ? err.message : '操作失败');
  } finally {
    setLoading(false);
  }
};
```

### 6. 无障碍支持

#### ARIA 属性
```typescript
<button
  aria-label="关闭对话框"
  aria-expanded={isOpen}
  aria-controls="dialog-content"
  aria-describedby="dialog-description"
>
  关闭
</button>
```

#### 键盘导航
```typescript
const handleKeyDown = (event: React.KeyboardEvent) => {
  switch (event.key) {
    case 'Enter':
    case ' ':
      event.preventDefault();
      handleClick();
      break;
    case 'Escape':
      handleClose();
      break;
  }
};
```

### 7. 性能优化

#### React.memo 使用
```typescript
const ExpensiveComponent = React.memo(({ data, onUpdate }) => {
  // 组件实现
}, (prevProps, nextProps) => {
  // 自定义比较函数
  return prevProps.data.id === nextProps.data.id;
});
```

#### useCallback 和 useMemo
```typescript
const handleClick = useCallback((id: string) => {
  onItemClick?.(id);
}, [onItemClick]);

const filteredData = useMemo(() => {
  return data.filter(item => item.status === 'active');
}, [data]);
```

## 组件测试规范

### 1. 单元测试
```typescript
import { render, screen, fireEvent } from '@testing-library/react';
import { Button } from './button';

describe('Button', () => {
  it('renders correctly', () => {
    render(<Button>Click me</Button>);
    expect(screen.getByRole('button')).toBeInTheDocument();
  });

  it('handles click events', () => {
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>Click me</Button>);
    
    fireEvent.click(screen.getByRole('button'));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('shows loading state', () => {
    render(<Button loading>Click me</Button>);
    expect(screen.getByRole('button')).toBeDisabled();
  });
});
```

### 2. 视觉回归测试
```typescript
import { render } from '@testing-library/react';
import { Button } from './button';

describe('Button Visual Tests', () => {
  it('matches snapshot for default variant', () => {
    const { container } = render(<Button>Default Button</Button>);
    expect(container.firstChild).toMatchSnapshot();
  });

  it('matches snapshot for all variants', () => {
    const variants = ['default', 'destructive', 'outline', 'secondary', 'ghost', 'link'];
    
    variants.forEach(variant => {
      const { container } = render(
        <Button variant={variant as any}>
          {variant} Button
        </Button>
      );
      expect(container.firstChild).toMatchSnapshot(`button-${variant}`);
    });
  });
});
```

## 组件文档规范

### 1. JSDoc 注释
```typescript
/**
 * 按钮组件 - 用于触发操作或导航
 * 
 * @example
 * ```tsx
 * <Button variant="default" size="lg" onClick={handleClick}>
 *   点击我
 * </Button>
 * ```
 */
interface ButtonProps {
  /**
   * 按钮的视觉变体
   * @default "default"
   */
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
  
  /**
   * 按钮的尺寸
   * @default "default"
   */
  size?: 'default' | 'sm' | 'lg' | 'icon';
  
  /**
   * 是否显示加载状态
   * @default false
   */
  loading?: boolean;
}
```

### 2. Storybook 故事
```typescript
import type { Meta, StoryObj } from '@storybook/react';
import { Button } from './button';

const meta: Meta<typeof Button> = {
  title: 'UI/Button',
  component: Button,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: ['default', 'destructive', 'outline', 'secondary', 'ghost', 'link'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    children: 'Button',
  },
};

export const Destructive: Story = {
  args: {
    variant: 'destructive',
    children: 'Delete',
  },
};

export const Loading: Story = {
  args: {
    loading: true,
    children: 'Loading...',
  },
};
```

## 组件维护指南

### 1. 版本控制
- 遵循语义化版本控制
- 重大变更需要迁移指南
- 保持向后兼容性

### 2. 性能监控
- 使用 React DevTools Profiler
- 监控组件渲染次数
- 优化重渲染问题

### 3. 用户反馈
- 收集组件使用反馈
- 定期审查组件API
- 持续改进用户体验

---

*本指南将随着项目发展持续更新，确保组件设计的一致性和最佳实践。*
