# LegalMind 仲裁平台系统设计文档

## 项目概述

LegalMind 是一个革命性的在线商业仲裁平台，提供安全、高效、AI赋能的数字化仲裁体验。本文档记录了系统的核心设计理念、组件架构和开发规范。

## 核心设计理念

### 四大核心哲学

1. **Trust through Clarity (透明建立信任)**
   - 透明直观的用户界面设计
   - 清晰的信息层次结构
   - 明确的操作反馈机制

2. **Efficiency through Intelligence (智能提升效率)**
   - AI功能节省用户时间
   - 自动化流程减少手动操作
   - 智能推荐和辅助决策

3. **Authority through Design (设计彰显权威)**
   - 专业的视觉语言
   - 高品质的用户体验
   - 符合法律行业标准的界面

4. **Innovation within Bounds (约束内的创新)**
   - 在法律框架内鼓励创新
   - 平衡创新与合规要求
   - 渐进式功能演进

### 设计原则

- **一致性优先**：统一的设计语言和交互模式
- **连通性保证**：模块间数据流畅传递
- **组件复用**：最大化组件的可复用性
- **响应式设计**：适配各种设备和屏幕尺寸
- **无障碍支持**：符合WCAG标准的可访问性

## 技术架构

### 前端技术栈

- **框架**: Next.js 14 (App Router)
- **语言**: TypeScript
- **UI组件**: shadcn/ui (基于 Radix UI)
- **样式**: Tailwind CSS
- **图标**: Lucide React
- **状态管理**: Zustand
- **表单处理**: React Hook Form + Zod
- **动画**: Framer Motion + CSS Animations

### 后端技术栈

- **API**: Next.js API Routes (Serverless)
- **数据库**: 待定 (建议 PostgreSQL + Prisma)
- **认证**: NextAuth.js
- **文件存储**: 待定 (建议 AWS S3 或 Supabase Storage)

## 目录结构

```
dev/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── (private)/         # 私有路由 (需要认证)
│   │   ├── (public)/          # 公共路由
│   │   └── api/               # API 路由
│   ├── components/            # 可复用组件
│   │   ├── ui/               # 基础UI组件
│   │   ├── layout/           # 布局组件
│   │   ├── forms/            # 表单组件
│   │   └── [feature]/        # 功能特定组件
│   ├── lib/                  # 工具函数和配置
│   ├── hooks/                # 自定义Hooks
│   ├── store/                # 状态管理
│   ├── styles/               # 样式文件
│   └── types/                # TypeScript类型定义
├── docs/                     # 文档
└── public/                   # 静态资源
```

## 核心模块

### 1. 认证与权限管理
- **角色系统**: 用户、仲裁员、管理员
- **权限控制**: 基于角色的访问控制 (RBAC)
- **会话管理**: 30分钟超时保护

### 2. 案件管理系统
- **案件生命周期**: 从申请到裁决的完整流程
- **文档管理**: 上传、预览、备注、版本控制
- **进展跟踪**: 自动化状态更新和里程碑管理

### 3. 在线庭审系统
- **视频会议**: 多方视频通话支持
- **庭审记录**: AI辅助记录和关键点标记
- **证据展示**: 实时证据共享和管理
- **流程控制**: 仲裁员主导的庭审流程

### 4. 调解管理系统
- **调解申请**: 在线申请和审核流程
- **会议安排**: 灵活的时间安排和通知系统
- **参与者管理**: 多方参与者的权限和状态管理

### 5. 仲裁员管理
- **仲裁员库**: 专业信息和评级系统
- **预约咨询**: 在线预约和咨询服务
- **工作负载**: 案件分配和工作量管理

### 6. 日程管理
- **泳道日历**: 多维度的日程展示
- **事件管理**: 创建、编辑、提醒功能
- **集成联动**: 与案件和庭审系统联动

### 7. AI智能助手
- **悬浮助手**: 全平台可用的AI助手
- **智能建议**: 基于上下文的建议和提醒
- **文档分析**: AI辅助的文档理解和摘要

## 组件设计规范

### 基础组件层次

1. **原子组件** (Atoms)
   - Button, Input, Badge, Avatar 等
   - 最小的可复用单元
   - 无业务逻辑，纯展示

2. **分子组件** (Molecules)
   - SearchBox, FormField, Card 等
   - 由原子组件组合而成
   - 包含简单的交互逻辑

3. **有机体组件** (Organisms)
   - Header, Sidebar, DataTable 等
   - 复杂的功能组件
   - 包含业务逻辑

4. **模板组件** (Templates)
   - PageLayout, FormLayout 等
   - 定义页面结构
   - 不包含具体内容

5. **页面组件** (Pages)
   - 具体的页面实现
   - 组合所有层次的组件
   - 包含完整的业务逻辑

### 组件命名规范

- **文件命名**: kebab-case (例: `user-profile.tsx`)
- **组件命名**: PascalCase (例: `UserProfile`)
- **Props接口**: 组件名 + Props (例: `UserProfileProps`)
- **Hook命名**: use + 功能描述 (例: `useUserProfile`)

### 组件结构模板

```typescript
// components/feature/component-name.tsx
'use client';

import React from 'react';
import { cn } from '@/lib/utils';

interface ComponentNameProps {
  className?: string;
  // 其他props
}

export function ComponentName({ 
  className,
  ...props 
}: ComponentNameProps) {
  return (
    <div className={cn("base-styles", className)}>
      {/* 组件内容 */}
    </div>
  );
}
```

## 状态管理规范

### Zustand Store 结构

```typescript
// store/feature-store.ts
import { create } from 'zustand';

interface FeatureState {
  // 状态定义
  data: DataType[];
  loading: boolean;
  error: string | null;
  
  // 动作定义
  fetchData: () => Promise<void>;
  updateData: (id: string, data: Partial<DataType>) => void;
  clearError: () => void;
}

export const useFeatureStore = create<FeatureState>((set, get) => ({
  data: [],
  loading: false,
  error: null,
  
  fetchData: async () => {
    set({ loading: true, error: null });
    try {
      // API调用
      const data = await fetchDataFromAPI();
      set({ data, loading: false });
    } catch (error) {
      set({ error: error.message, loading: false });
    }
  },
  
  updateData: (id, newData) => {
    set(state => ({
      data: state.data.map(item => 
        item.id === id ? { ...item, ...newData } : item
      )
    }));
  },
  
  clearError: () => set({ error: null })
}));
```

## 样式设计规范

### 颜色系统

- **主色调**: Orange (#FF6B35, #E55A2B)
- **辅助色**: Blue (#3B82F6), Green (#10B981), Red (#EF4444)
- **中性色**: Gray 系列 (#F8F9FA ~ #1A1A1A)
- **语义色**: Success, Warning, Error, Info

### 字体系统

- **主字体**: Inter (英文), PingFang SC (中文)
- **字体大小**: 12px ~ 48px (使用 Tailwind 的 text-* 类)
- **字重**: 400 (normal), 500 (medium), 600 (semibold), 700 (bold)

### 间距系统

- **基础单位**: 4px (0.25rem)
- **常用间距**: 4px, 8px, 12px, 16px, 20px, 24px, 32px, 48px
- **使用 Tailwind 的 spacing scale**

### 圆角系统

- **小圆角**: 4px (rounded)
- **中圆角**: 8px (rounded-lg)
- **大圆角**: 12px (rounded-xl)
- **圆形**: 50% (rounded-full)

### 阴影系统

- **轻微阴影**: shadow-sm
- **标准阴影**: shadow
- **中等阴影**: shadow-md
- **重阴影**: shadow-lg
- **品牌阴影**: shadow-brand (自定义橙色阴影)

## 动画设计规范

### 动画原则

- **有意义的动画**: 每个动画都应该有明确的目的
- **性能优先**: 使用 transform 和 opacity 属性
- **时长控制**: 快速交互 150ms，页面转换 300ms，复杂动画 500ms
- **缓动函数**: ease-out (默认), ease-in-out (平滑), cubic-bezier (自定义)

### 动画类型

1. **微交互动画**
   - 按钮悬停效果
   - 表单验证反馈
   - 加载状态指示

2. **页面转换动画**
   - 路由切换效果
   - 模态框显示/隐藏
   - 侧边栏展开/收起

3. **数据变化动画**
   - 列表项添加/删除
   - 数据更新反馈
   - 状态变化指示

### 动画实现方式

```css
/* CSS 动画 */
.animate-fade-in {
  animation: fadeIn 0.5s ease-out;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

/* Tailwind 动画类 */
.hover-lift {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.hover-lift:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}
```

## 响应式设计规范

### 断点系统

- **sm**: 640px (小屏手机横屏/大屏手机竖屏)
- **md**: 768px (平板竖屏)
- **lg**: 1024px (平板横屏/小屏笔记本)
- **xl**: 1280px (桌面显示器)
- **2xl**: 1536px (大屏显示器)

### 设计策略

- **移动优先**: 从小屏幕开始设计，逐步增强
- **内容优先**: 确保核心内容在所有设备上可访问
- **触摸友好**: 按钮最小44px，间距充足
- **性能考虑**: 图片懒加载，代码分割

### 布局模式

```css
/* 响应式网格 */
.responsive-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 1rem;
}

@media (min-width: 640px) {
  .responsive-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: 1.5rem;
  }
}

@media (min-width: 1024px) {
  .responsive-grid {
    grid-template-columns: repeat(3, 1fr);
    gap: 2rem;
  }
}
```

## 数据流设计

### 数据流向

1. **用户操作** → UI组件
2. **UI组件** → Store Actions
3. **Store Actions** → API调用
4. **API响应** → Store State更新
5. **Store State** → UI组件重新渲染

### 错误处理

- **网络错误**: 显示重试按钮
- **验证错误**: 实时表单验证反馈
- **权限错误**: 重定向到登录页面
- **系统错误**: 显示友好的错误页面

### 加载状态

- **骨架屏**: 内容加载时的占位符
- **加载指示器**: 操作进行中的反馈
- **进度条**: 长时间操作的进度显示

## 性能优化规范

### 代码分割

- **路由级分割**: 每个页面独立打包
- **组件级分割**: 大型组件懒加载
- **第三方库分割**: vendor chunk 独立

### 图片优化

- **格式选择**: WebP > JPEG > PNG
- **尺寸优化**: 响应式图片，多尺寸支持
- **懒加载**: 视口外图片延迟加载

### 缓存策略

- **静态资源**: 长期缓存 + 版本控制
- **API响应**: 适当的缓存时间
- **用户数据**: 本地存储 + 同步机制

## 测试规范

### 测试层次

1. **单元测试**: 组件和函数的独立测试
2. **集成测试**: 组件间交互测试
3. **端到端测试**: 完整用户流程测试

### 测试工具

- **单元测试**: Jest + React Testing Library
- **端到端测试**: Playwright 或 Cypress
- **类型检查**: TypeScript 编译器

### 测试覆盖率

- **目标覆盖率**: 80% 以上
- **关键路径**: 100% 覆盖
- **边界情况**: 充分测试

## 安全规范

### 前端安全

- **XSS防护**: 输入验证和输出编码
- **CSRF防护**: Token验证
- **内容安全策略**: CSP头部配置

### 数据安全

- **敏感数据**: 不在前端存储
- **传输加密**: HTTPS强制使用
- **访问控制**: 基于角色的权限验证

## 部署规范

### 环境配置

- **开发环境**: 本地开发和测试
- **预发布环境**: 生产环境的镜像
- **生产环境**: 正式服务环境

### CI/CD流程

1. **代码提交** → Git仓库
2. **自动构建** → 运行测试
3. **质量检查** → 代码审查
4. **自动部署** → 环境更新
5. **监控告警** → 运行状态监控

---

*本文档将随着项目发展持续更新，确保设计规范与实际实现保持一致。*
