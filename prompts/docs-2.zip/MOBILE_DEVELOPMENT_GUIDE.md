# LegalMind 仲裁平台移动端开发指南

**文档版本**: Version 0.5  
**完成日期**: 2025年8月22日  
**项目负责人**: 方寒（独立开发者）  
**项目状态**: 前端原型已完成，准备全栈开发  

## 1. 移动端开发概述

### 1.1 开发策略
基于LegalMind仲裁平台Web端的成功实现，移动端开发采用以下策略：
- **技术栈**: React Native + Expo 开发框架
- **设计理念**: 延续Web端四大核心哲学，适配移动端交互特性
- **功能范围**: 核心功能全覆盖，针对移动场景优化
- **性能目标**: 启动时间<3秒，流畅度60FPS，内存使用<200MB

### 1.2 架构设计
```
┌─────────────────────────────────────────────────────────────┐
│                    移动端应用架构                            │
├─────────────────────────────────────────────────────────────┤
│  UI层: React Native + Expo + NativeBase/Tamagui            │
├─────────────────────────────────────────────────────────────┤
│  状态管理: Zustand + TanStack Query + AsyncStorage         │
├─────────────────────────────────────────────────────────────┤
│  导航路由: React Navigation 6 + Deep Linking               │
├─────────────────────────────────────────────────────────────┤
│  网络层: Axios + API Client + Offline Support              │
├─────────────────────────────────────────────────────────────┤
│  原生功能: Camera + File System + Push Notifications       │
├─────────────────────────────────────────────────────────────┤
│  安全层: Keychain + Biometric + Certificate Pinning        │
└─────────────────────────────────────────────────────────────┘
```

## 2. 技术栈规范

### 2.1 核心技术组件
| 技术组件 | 版本要求 | 用途说明 | 性能指标 |
|---------|---------|---------|---------|
| React Native | 0.72+ | 跨平台移动开发框架 | 启动时间 < 3s |
| Expo | 49.0+ | 开发工具链和原生功能 | 热更新 < 5s |
| TypeScript | 5.0+ | 类型安全开发 | 编译时间 < 30s |
| React Navigation | 6.0+ | 导航管理 | 页面切换 < 300ms |
| Zustand | 4.4+ | 状态管理 | 状态更新 < 10ms |
| TanStack Query | 5.0+ | 数据获取和缓存 | 缓存命中率 > 80% |
| AsyncStorage | Latest | 本地数据存储 | 读写速度 < 10ms |

### 2.2 UI组件库选择
```typescript
// 推荐使用 Tamagui 实现跨平台UI一致性
import { TamaguiProvider, Theme, Button, Input, Card } from '@tamagui/core'

// 或者使用 NativeBase 作为备选方案
import { NativeBaseProvider, Box, Text, VStack } from 'native-base'

// 自定义主题配置
const theme = {
  colors: {
    primary: '#FF6B35',      // LegalMind 主色调
    secondary: '#FFFFFF',    // 辅助色
    success: '#10B981',      // 成功色
    warning: '#F59E0B',      // 警告色
    error: '#EF4444',        // 错误色
    info: '#3B82F6'          // 信息色
  },
  fonts: {
    heading: 'PingFang SC',
    body: 'PingFang SC'
  }
}
```

### 2.3 项目结构规范
```
mobile-app/
├── src/
│   ├── components/          # 通用组件
│   │   ├── common/         # 基础组件
│   │   ├── forms/          # 表单组件
│   │   ├── navigation/     # 导航组件
│   │   └── business/       # 业务组件
│   ├── screens/            # 页面组件
│   │   ├── auth/          # 认证相关页面
│   │   ├── cases/         # 案件管理页面
│   │   ├── hearings/      # 庭审相关页面
│   │   ├── documents/     # 文档管理页面
│   │   ├── messages/      # 消息中心页面
│   │   └── profile/       # 个人中心页面
│   ├── navigation/         # 导航配置
│   ├── services/          # API服务
│   ├── store/             # 状态管理
│   ├── utils/             # 工具函数
│   ├── hooks/             # 自定义Hooks
│   ├── types/             # TypeScript类型
│   └── constants/         # 常量配置
├── assets/                # 静态资源
├── android/               # Android原生代码
├── ios/                   # iOS原生代码
└── app.json              # Expo配置
```

## 3. 核心功能实现

### 3.1 用户认证模块

#### 生物识别认证
```typescript
import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';

export class BiometricAuth {
  static async isAvailable(): Promise<boolean> {
    const hasHardware = await LocalAuthentication.hasHardwareAsync();
    const isEnrolled = await LocalAuthentication.isEnrolledAsync();
    return hasHardware && isEnrolled;
  }

  static async authenticate(): Promise<boolean> {
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: '请验证身份以登录LegalMind',
      cancelLabel: '取消',
      fallbackLabel: '使用密码'
    });
    return result.success;
  }

  static async storeCredentials(token: string): Promise<void> {
    await SecureStore.setItemAsync('auth_token', token);
  }

  static async getCredentials(): Promise<string | null> {
    return await SecureStore.getItemAsync('auth_token');
  }
}
```

#### 实名认证组件
```typescript
import { Camera } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';

export const IdentityVerification: React.FC = () => {
  const [cameraPermission, requestCameraPermission] = Camera.useCameraPermissions();
  const [idCardFront, setIdCardFront] = useState<string | null>(null);
  const [idCardBack, setIdCardBack] = useState<string | null>(null);
  const [faceImage, setFaceImage] = useState<string | null>(null);

  const takePhoto = async (type: 'idFront' | 'idBack' | 'face') => {
    if (!cameraPermission?.granted) {
      await requestCameraPermission();
    }

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: type === 'face' ? [1, 1] : [16, 10],
      quality: 0.8,
    });

    if (!result.canceled) {
      const imageUri = result.assets[0].uri;
      switch (type) {
        case 'idFront':
          setIdCardFront(imageUri);
          break;
        case 'idBack':
          setIdCardBack(imageUri);
          break;
        case 'face':
          setFaceImage(imageUri);
          break;
      }
    }
  };

  const submitVerification = async () => {
    const formData = new FormData();
    formData.append('idCardFront', {
      uri: idCardFront,
      type: 'image/jpeg',
      name: 'id_front.jpg'
    } as any);
    formData.append('idCardBack', {
      uri: idCardBack,
      type: 'image/jpeg',
      name: 'id_back.jpg'
    } as any);
    formData.append('faceImage', {
      uri: faceImage,
      type: 'image/jpeg',
      name: 'face.jpg'
    } as any);

    await apiClient.post('/auth/verification', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  };

  return (
    <VStack space={4} p={4}>
      <Text fontSize="lg" fontWeight="bold">身份认证</Text>
      
      <Button onPress={() => takePhoto('idFront')}>
        拍摄身份证正面
      </Button>
      {idCardFront && <Image source={{ uri: idCardFront }} />}
      
      <Button onPress={() => takePhoto('idBack')}>
        拍摄身份证背面
      </Button>
      {idCardBack && <Image source={{ uri: idCardBack }} />}
      
      <Button onPress={() => takePhoto('face')}>
        拍摄人脸照片
      </Button>
      {faceImage && <Image source={{ uri: faceImage }} />}
      
      <Button 
        onPress={submitVerification}
        isDisabled={!idCardFront || !idCardBack || !faceImage}
      >
        提交认证
      </Button>
    </VStack>
  );
};
```

### 3.2 案件管理模块

#### 案件列表组件
```typescript
import { FlashList } from '@shopify/flash-list';
import { RefreshControl } from 'react-native';

export const CaseList: React.FC = () => {
  const { data: cases, isLoading, refetch } = useQuery({
    queryKey: ['cases'],
    queryFn: () => apiClient.get('/cases')
  });

  const renderCaseItem = ({ item }: { item: Case }) => (
    <Card m={2} p={4}>
      <VStack space={2}>
        <HStack justifyContent="space-between">
          <Text fontSize="md" fontWeight="bold">{item.title}</Text>
          <Badge colorScheme={getStatusColor(item.status)}>
            {getStatusText(item.status)}
          </Badge>
        </HStack>
        <Text fontSize="sm" color="gray.600">
          案件编号: {item.caseNumber}
        </Text>
        <Text fontSize="sm" color="gray.600">
          争议金额: ¥{item.disputeAmount?.toLocaleString()}
        </Text>
        <Text fontSize="xs" color="gray.500">
          创建时间: {formatDate(item.createdAt)}
        </Text>
      </VStack>
    </Card>
  );

  return (
    <Box flex={1}>
      <FlashList
        data={cases}
        renderItem={renderCaseItem}
        estimatedItemSize={120}
        refreshControl={
          <RefreshControl refreshing={isLoading} onRefresh={refetch} />
        }
        ListEmptyComponent={
          <Center flex={1}>
            <Text>暂无案件</Text>
          </Center>
        }
      />
    </Box>
  );
};
```

### 3.3 文档管理模块

#### 文档上传组件
```typescript
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';

export const DocumentUpload: React.FC<{ caseId: string }> = ({ caseId }) => {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const pickDocument = async () => {
    const result = await DocumentPicker.getDocumentAsync({
      type: ['application/pdf', 'image/*', 'application/msword'],
      copyToCacheDirectory: true
    });

    if (!result.canceled) {
      await uploadDocument(result.assets[0]);
    }
  };

  const uploadDocument = async (document: DocumentPicker.DocumentPickerAsset) => {
    setUploading(true);
    setUploadProgress(0);

    try {
      const formData = new FormData();
      formData.append('file', {
        uri: document.uri,
        type: document.mimeType,
        name: document.name
      } as any);
      formData.append('documentType', 'evidence');
      formData.append('title', document.name);

      await apiClient.post(`/cases/${caseId}/documents`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          const progress = progressEvent.loaded / progressEvent.total;
          setUploadProgress(progress);
        }
      });

      Toast.show({
        title: '文档上传成功',
        status: 'success'
      });
    } catch (error) {
      Toast.show({
        title: '文档上传失败',
        status: 'error'
      });
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  return (
    <VStack space={4} p={4}>
      <Button onPress={pickDocument} isDisabled={uploading}>
        选择文档
      </Button>
      
      {uploading && (
        <VStack space={2}>
          <Progress value={uploadProgress * 100} />
          <Text textAlign="center">
            上传中... {Math.round(uploadProgress * 100)}%
          </Text>
        </VStack>
      )}
    </VStack>
  );
};
```

### 3.4 推送通知模块

#### 推送通知配置
```typescript
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';

export class PushNotificationService {
  static async registerForPushNotifications(): Promise<string | null> {
    if (!Device.isDevice) {
      return null;
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      return null;
    }

    const token = (await Notifications.getExpoPushTokenAsync()).data;
    
    // 发送token到服务器
    await apiClient.post('/users/push-token', { token });
    
    return token;
  }

  static setupNotificationHandlers() {
    // 前台通知处理
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
      }),
    });

    // 通知点击处理
    Notifications.addNotificationResponseReceivedListener(response => {
      const data = response.notification.request.content.data;
      
      if (data.type === 'case_update') {
        // 导航到案件详情页
        navigationRef.navigate('CaseDetail', { caseId: data.caseId });
      } else if (data.type === 'hearing_reminder') {
        // 导航到庭审页面
        navigationRef.navigate('HearingRoom', { hearingId: data.hearingId });
      }
    });
  }
}
```

## 4. 性能优化策略

### 4.1 内存管理
```typescript
// 图片缓存优化
import { Image } from 'expo-image';

const OptimizedImage: React.FC<{ uri: string }> = ({ uri }) => (
  <Image
    source={{ uri }}
    style={{ width: 100, height: 100 }}
    cachePolicy="memory-disk"
    recyclingKey={uri}
    contentFit="cover"
  />
);

// 列表性能优化
const CaseListOptimized: React.FC = () => {
  const getItemLayout = useCallback((data: any, index: number) => ({
    length: 120,
    offset: 120 * index,
    index,
  }), []);

  return (
    <FlashList
      data={cases}
      renderItem={renderCaseItem}
      estimatedItemSize={120}
      getItemLayout={getItemLayout}
      removeClippedSubviews={true}
      maxToRenderPerBatch={10}
      windowSize={10}
    />
  );
};
```

### 4.2 网络优化
```typescript
// 离线支持
import NetInfo from '@react-native-async-storage/async-storage';

export const useOfflineSupport = () => {
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      setIsOnline(state.isConnected ?? false);
    });

    return unsubscribe;
  }, []);

  return { isOnline };
};

// 请求缓存策略
export const apiClient = axios.create({
  baseURL: 'https://api.legalmind.com/v1',
  timeout: 10000,
});

// 添加缓存拦截器
apiClient.interceptors.response.use(
  async (response) => {
    if (response.config.method === 'get') {
      await AsyncStorage.setItem(
        `cache_${response.config.url}`,
        JSON.stringify(response.data)
      );
    }
    return response;
  },
  async (error) => {
    if (!error.response && error.config.method === 'get') {
      // 网络错误时尝试从缓存读取
      const cached = await AsyncStorage.getItem(`cache_${error.config.url}`);
      if (cached) {
        return { data: JSON.parse(cached) };
      }
    }
    throw error;
  }
);
```

## 5. 平台适配指南

### 5.1 iOS适配要点
```typescript
// iOS特定配置
const iosConfig = {
  // 状态栏配置
  statusBar: {
    barStyle: 'dark-content',
    backgroundColor: '#FFFFFF'
  },
  
  // 安全区域处理
  safeAreaInsets: {
    top: 44,
    bottom: 34
  },
  
  // 导航栏配置
  navigationBar: {
    backgroundColor: '#FFFFFF',
    titleColor: '#000000',
    tintColor: '#FF6B35'
  }
};

// iOS权限请求
const requestiOSPermissions = async () => {
  // 相机权限
  const cameraStatus = await Camera.requestCameraPermissionsAsync();
  
  // 照片库权限
  const mediaLibraryStatus = await ImagePicker.requestMediaLibraryPermissionsAsync();
  
  // 通知权限
  const notificationStatus = await Notifications.requestPermissionsAsync();
  
  return {
    camera: cameraStatus.granted,
    mediaLibrary: mediaLibraryStatus.granted,
    notifications: notificationStatus.granted
  };
};
```

### 5.2 Android适配要点
```typescript
// Android特定配置
const androidConfig = {
  // 状态栏配置
  statusBar: {
    backgroundColor: '#FF6B35',
    translucent: false
  },
  
  // 导航栏配置
  navigationBar: {
    backgroundColor: '#FFFFFF'
  },
  
  // 权限配置
  permissions: [
    'CAMERA',
    'READ_EXTERNAL_STORAGE',
    'WRITE_EXTERNAL_STORAGE',
    'RECORD_AUDIO'
  ]
};

// Android权限处理
import { PermissionsAndroid } from 'react-native';

const requestAndroidPermissions = async () => {
  const permissions = [
    PermissionsAndroid.PERMISSIONS.CAMERA,
    PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
    PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
    PermissionsAndroid.PERMISSIONS.RECORD_AUDIO
  ];

  const granted = await PermissionsAndroid.requestMultiple(permissions);
  
  return Object.values(granted).every(
    permission => permission === PermissionsAndroid.RESULTS.GRANTED
  );
};
```

## 6. 测试策略

### 6.1 单元测试
```typescript
// 使用Jest + React Native Testing Library
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import { CaseList } from '../CaseList';

describe('CaseList', () => {
  it('should render case items correctly', async () => {
    const { getByText } = render(<CaseList />);
    
    await waitFor(() => {
      expect(getByText('建设工程合同纠纷案')).toBeTruthy();
    });
  });

  it('should handle refresh correctly', async () => {
    const { getByTestId } = render(<CaseList />);
    const refreshControl = getByTestId('refresh-control');
    
    fireEvent(refreshControl, 'refresh');
    
    await waitFor(() => {
      // 验证刷新逻辑
    });
  });
});
```

### 6.2 集成测试
```typescript
// 使用Detox进行E2E测试
describe('Authentication Flow', () => {
  beforeAll(async () => {
    await device.launchApp();
  });

  it('should login successfully', async () => {
    await element(by.id('email-input')).typeText('test@example.com');
    await element(by.id('password-input')).typeText('password123');
    await element(by.id('login-button')).tap();
    
    await expect(element(by.id('dashboard'))).toBeVisible();
  });
});
```

## 7. 发布部署

### 7.1 构建配置
```json
// app.json
{
  "expo": {
    "name": "LegalMind仲裁平台",
    "slug": "legalmind-arbitration",
    "version": "1.0.0",
    "platforms": ["ios", "android"],
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#FF6B35"
    },
    "ios": {
      "bundleIdentifier": "com.legalmind.arbitration",
      "buildNumber": "1",
      "supportsTablet": true
    },
    "android": {
      "package": "com.legalmind.arbitration",
      "versionCode": 1,
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#FFFFFF"
      }
    }
  }
}
```

### 7.2 发布流程
```bash
# 构建iOS版本
eas build --platform ios --profile production

# 构建Android版本
eas build --platform android --profile production

# 提交到应用商店
eas submit --platform ios
eas submit --platform android

# 热更新发布
eas update --branch production --message "修复登录问题"
```

---

*本移动端开发指南基于LegalMind仲裁平台Web端原型制定，为移动端APP开发提供完整的技术规范和实施指导。*
