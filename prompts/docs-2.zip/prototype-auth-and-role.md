# 前端原型：登录与身份选择机制（Auth & Role Prototype)

本文件记录在线庭审系统前端原型中“登录 → 身份选择 → 进入工作台/仲裁员工作台”的机制设计、路由连通、可测指引与后续对接点。

## 目标与范围
- 无后端鉴权前提下，提供稳定且可测的登录与角色切换体验。
- 全链路连通：登录页 → 身份选择页 → 工作台（/dashboard）或仲裁员工作台（/arbitrator/dashboard）。
- 与既有私有区布局、侧边栏权限和页面导航一致。

## 页面与路由
- 登录页：`/login`
- 身份选择页：`/role-selection`
- 工作台（当事人）：`/dashboard`
- 仲裁员工作台：`/arbitrator/dashboard`

## 行为与规则
### 1) 登录页 → 身份选择页
- 登录提交后跳转：`/role-selection?email=<用户填入邮箱>`。
- 登录时会将 mock 用户写入 Zustand userStore（前端原型）。

### 2) 身份选择页（Role Selection）
- 判定“是否可选择仲裁员”（canArbitrate）：
  - URL 参数：`?arbitrator=1` 或 `?arbitrator=true` → 可选仲裁员。
  - 邮箱规则：`email` 以 `arb@` 开头 → 可选仲裁员。
- 进入页面若未登录（无 userStore 会话），自动设置“guest 匿名登录态”：
  - 使用 mockUser/mockProfile 写入 `useUserStore`，以保证私有区可访问与导航一致。
- 选择角色：
  - 将 `userRole` 写入 `localStorage`；
  - `arbitrator` → 跳转 `/arbitrator/dashboard`；
  - `party`（当事人）→ 跳转 `/dashboard`。
- UI：仲裁员卡片在不可选时置灰并提示原因；当事人卡片始终可用。
- 说明文案：提示可通过 URL 参数或邮箱前缀模拟仲裁员权限。

### 3) 顶部 Header 身份徽标与切换
- 在私有区 Header 右侧显示当前身份徽章（仲裁员/当事人）。
- 提供“切换身份”链接，跳转 `/role-selection`，便于快速变更身份并回归对应工作台。

## 私有区与守卫
- 私有区布局文件：`src/app/(private)/layout.tsx` 继续使用 `useAuthGuard()` 进行轻量守卫（未登录访问私有区将重定向至 `/login`）。
- 因为 Role Selection 页面会在必要时自动设置 guest，会话建立后再进入私有区可正常访问。

## 角色与权限一致性
- 侧边栏 `AppSidebar` 根据 `currentRole` 生成导航项；首次渲染展开包含当前路径的分组。
- Bug 修正：将 `const { currentRole } = useRole()` 提前到 `useEffect` 之前，避免初始化顺序造成的 `ReferenceError`。

## URL 与 Tabs 一致性
- 新增通用 Hook：`useSyncedTab(allowedTabs, defaultTab)`（`dev/src/lib/hooks/use-synced-tab.ts`）。
- 案件详情页采用该 Hook 保持 `?tab` 同步（合法值白名单、默认回退、`router.replace` 写回）。
- 后续可按需复用到其它有 Tabs 的页面（如日程等）。

## 可测要点（建议用例）
1. 当事人路径：`/login` → 输入 `user@example.com` → `/role-selection` → 选择“当事人” → `/dashboard`。
2. 仲裁员路径A（邮箱）：`/login` → 输入 `arb@legalmind.com` → `/role-selection` → 选择“仲裁员” → `/arbitrator/dashboard`。
3. 仲裁员路径B（参数）：直接访问 `/role-selection?email=u@x.com&arbitrator=1` → 选择“仲裁员”。
4. 未登录直达角色页：`/role-selection` 应自动设置 guest 登录态，可正常进入目标工作台。
5. Header 身份徽章与“切换身份”链接显示正确，切换后工作台与侧边栏菜单随角色变化。

## 与庭审流程的连通
- 案件详情页已提供直达“进入等候室/进入庭审”的入口（hearingId = `hearing-<caseId>`）。
- 等候室完成前置流程后进入 live，sessionStorage 中的证人名单与 live 右侧“来自等候室”联动。

## 后续对接点（为真实鉴权预留）
- 登录后将从后端获取用户权限与角色集；前端只负责呈现。
- Role Selection 可由后端返回可选角色列表与策略（当前前端规则将移除）。
- Header 身份徽章可显示更完整的组织/岗位信息。
- `useAuthGuard` 可升级为 SSR 鉴权（如 NextAuth / 自研方案）。


