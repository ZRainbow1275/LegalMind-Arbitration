# LegalMind 仲裁平台 - 主文档索引

**文档版本**: Version 0.5  
**完成日期**: 2025年8月22日  
**项目负责人**: 方寒（独立开发者）  
**项目状态**: 前端原型已完成，准备全栈开发  

## 文档导航指南

本文档索引提供LegalMind仲裁平台所有文档的导航和使用指南，确保开发团队、投资方、合作伙伴能够快速找到所需的技术和业务文档。

## 1. 核心技术文档（dev/docs/）

### 1.1 项目规格文档
| 文档名称 | 文件路径 | 用途说明 | 目标读者 |
|---------|---------|---------|---------|
| **需求规格说明书** | [REQUIREMENTS_SPECIFICATION.md](./REQUIREMENTS_SPECIFICATION.md) | 完整的功能需求和非功能需求规格 | 开发团队、产品经理、投资方 |
| **技术参数文档** | [TECHNICAL_PARAMETERS.md](./TECHNICAL_PARAMETERS.md) | 详细的技术参数、性能指标、工作量评估 | 技术团队、项目经理、预算评估 |
| **项目概览** | [PROJECT_OVERVIEW.md](./PROJECT_OVERVIEW.md) | 项目整体介绍、架构说明、核心功能 | 所有相关人员 |

### 1.2 技术设计文档
| 文档名称 | 文件路径 | 用途说明 | 目标读者 |
|---------|---------|---------|---------|
| **API设计规范** | [API_DESIGN_SPECIFICATION.md](./API_DESIGN_SPECIFICATION.md) | 完整的API接口设计和规范 | 后端开发、前端开发、测试 |
| **数据库设计** | [DATABASE_DESIGN.md](./DATABASE_DESIGN.md) | 数据库架构、表结构、性能优化 | 后端开发、DBA、架构师 |
| **API参考文档** | [API_REFERENCE.md](./API_REFERENCE.md) | API接口的详细参考文档 | 前端开发、移动端开发 |

### 1.3 开发指南文档
| 文档名称 | 文件路径 | 用途说明 | 目标读者 |
|---------|---------|---------|---------|
| **组件使用指南** | [COMPONENT_GUIDE.md](./COMPONENT_GUIDE.md) | 前端组件的使用方法和最佳实践 | 前端开发、UI开发 |
| **移动端开发指南** | [MOBILE_DEVELOPMENT_GUIDE.md](./MOBILE_DEVELOPMENT_GUIDE.md) | 移动端APP和小程序开发规范 | 移动端开发、小程序开发 |
| **系统设计文档** | [SYSTEM_DESIGN.md](./SYSTEM_DESIGN.md) | 系统架构设计和技术选型 | 架构师、技术负责人 |

### 1.4 流程管理文档
| 文档名称 | 文件路径 | 用途说明 | 目标读者 |
|---------|---------|---------|---------|
| **开发工作流程** | [DEVELOPMENT_WORKFLOW.md](./DEVELOPMENT_WORKFLOW.md) | 开发流程、代码规范、质量控制 | 开发团队、项目经理 |
| **文档整合计划** | [DOCUMENT_CONSOLIDATION_PLAN.md](./DOCUMENT_CONSOLIDATION_PLAN.md) | 文档一致性管理和维护规范 | 文档管理员、项目经理 |

## 2. 辅助参考文档（docs/）

### 2.1 项目规划文档
| 文档名称 | 文件路径 | 用途说明 | 目标读者 |
|---------|---------|---------|---------|
| **需求概述** | [../docs/requirements.md](../docs/requirements.md) | 需求规格的简化版本 | 快速了解项目需求 |
| **技术栈规格** | [../docs/tech-stack.md](../docs/tech-stack.md) | 详细的技术栈说明和选型理由 | 技术团队、架构师 |
| **开发成本估算** | [../docs/development-cost-estimation.md](../docs/development-cost-estimation.md) | 基于前端原型的开发成本评估 | 项目经理、投资方 |

### 2.2 设计规范文档
| 文档名称 | 文件路径 | 用途说明 | 目标读者 |
|---------|---------|---------|---------|
| **设计系统** | [../docs/design-system.md](../docs/design-system.md) | UI设计系统和组件规范 | UI设计师、前端开发 |
| **UI/UX规范** | [../docs/ui-ux-spec.md](../docs/ui-ux-spec.md) | 用户体验设计规范 | UX设计师、产品经理 |
| **设计语言** | [../docs/design-language.md](../docs/design-language.md) | 品牌设计语言和视觉规范 | 设计团队 |

### 2.3 项目管理文档
| 文档名称 | 文件路径 | 用途说明 | 目标读者 |
|---------|---------|---------|---------|
| **开发计划** | [../docs/dev-plan.md](../docs/dev-plan.md) | 项目开发计划和里程碑 | 项目经理、开发团队 |
| **进度跟踪** | [../docs/progress.md](../docs/progress.md) | 项目进度和完成情况 | 项目经理、相关方 |
| **问题日志** | [../docs/issue-log.md](../docs/issue-log.md) | 开发过程中的问题记录 | 开发团队、测试团队 |

## 3. 文档使用指南

### 3.1 不同角色的文档阅读路径

#### 投资方/决策者
1. [项目概览](./PROJECT_OVERVIEW.md) - 了解项目整体情况
2. [需求规格说明书](./REQUIREMENTS_SPECIFICATION.md) - 了解功能需求
3. [开发成本估算](../docs/development-cost-estimation.md) - 了解投资预算
4. [技术参数文档](./TECHNICAL_PARAMETERS.md) - 了解技术可行性

#### 后端开发团队
1. [API设计规范](./API_DESIGN_SPECIFICATION.md) - API接口设计
2. [数据库设计](./DATABASE_DESIGN.md) - 数据库架构
3. [技术参数文档](./TECHNICAL_PARAMETERS.md) - 技术要求
4. [开发工作流程](./DEVELOPMENT_WORKFLOW.md) - 开发规范

#### 移动端开发团队
1. [移动端开发指南](./MOBILE_DEVELOPMENT_GUIDE.md) - 移动端开发规范
2. [API参考文档](./API_REFERENCE.md) - API接口调用
3. [技术参数文档](./TECHNICAL_PARAMETERS.md) - 性能要求
4. [组件使用指南](./COMPONENT_GUIDE.md) - 组件复用

#### 前端开发团队
1. [组件使用指南](./COMPONENT_GUIDE.md) - 组件使用方法
2. [API参考文档](./API_REFERENCE.md) - API接口调用
3. [设计系统](../docs/design-system.md) - UI设计规范
4. [开发工作流程](./DEVELOPMENT_WORKFLOW.md) - 开发规范

#### 测试团队
1. [需求规格说明书](./REQUIREMENTS_SPECIFICATION.md) - 测试需求
2. [API设计规范](./API_DESIGN_SPECIFICATION.md) - 接口测试
3. [技术参数文档](./TECHNICAL_PARAMETERS.md) - 性能测试标准
4. [开发工作流程](./DEVELOPMENT_WORKFLOW.md) - 测试流程

### 3.2 文档版本控制

#### 版本号规范
- **主版本号**: 重大架构变更或功能重构
- **次版本号**: 功能新增或重要更新
- **修订号**: 错误修正或小幅改进

#### 当前版本状态
- **Version 0.5**: 前端原型完成，准备全栈开发
- **下一版本**: Version 1.0 - 后端开发完成
- **目标版本**: Version 2.0 - 移动端开发完成

### 3.3 文档更新机制

#### 更新触发条件
- 需求变更时更新需求规格说明书
- 技术选型变更时更新技术参数文档
- API设计变更时更新API设计规范
- 数据库结构变更时更新数据库设计文档

#### 更新责任人
- **项目经理**: 负责项目管理类文档更新
- **架构师**: 负责技术设计类文档更新
- **开发负责人**: 负责开发指南类文档更新
- **文档管理员**: 负责文档一致性检查

## 4. 文档质量保证

### 4.1 一致性检查清单
- [ ] 技术栈版本号统一
- [ ] 功能模块描述一致
- [ ] API接口定义统一
- [ ] 数据库设计一致
- [ ] 项目信息统一

### 4.2 定期审查机制
- **周审查**: 开发过程中的文档同步更新
- **月审查**: 文档一致性和完整性检查
- **版本审查**: 重大版本发布前的全面文档审查

### 4.3 文档反馈机制
- **内部反馈**: 开发团队内部的文档改进建议
- **外部反馈**: 客户和合作伙伴的文档使用反馈
- **持续改进**: 基于反馈的文档质量持续改进

---

*本文档索引确保LegalMind仲裁平台的所有文档能够被正确使用和维护，为项目的成功实施提供完整的文档支撑。*
