# LegalMind 组件使用指南

## 核心组件库

### 1. 数据同步系统 (data-sync.ts)

#### 功能概述
全平台模块间数据同步机制，提供统一的数据同步、状态管理和事件通知功能。

#### 使用方法
```typescript
import { useModuleSync, dataSyncManager } from '@/lib/data-sync';

// 在组件中使用
const moduleSync = useModuleSync('module-name');

// 注册模块
useEffect(() => {
  moduleSync.register();
  
  // 订阅事件
  const unsubscribe = moduleSync.subscribeToEvents((event) => {
    // 处理同步事件
  });
  
  return () => {
    unsubscribe();
    moduleSync.unregister();
  };
}, []);

// 发布事件
dataSyncManager.publishCaseEvent('created', caseData, 'source-module');
```

#### 支持的事件类型
- `case_created`, `case_updated`, `case_deleted`
- `mediation_created`, `mediation_updated`, `mediation_completed`
- `hearing_scheduled`, `hearing_started`, `hearing_completed`
- `document_uploaded`, `document_signed`, `document_approved`
- `message_sent`, `message_received`
- `notification_created`, `notification_read`

### 2. 程序跟踪组件 (ProcedureTracker)

#### 功能概述
支持仲裁和调解程序的实时跟踪和管理，提供程序步骤的可视化展示。

#### 使用方法
```typescript
import { ProcedureTracker } from '@/components/hearings/procedure-tracker';

<ProcedureTracker
  hearingType="arbitration" // 或 "mediation"
  currentStep="investigation"
  onStepChange={(stepId) => console.log('步骤变更:', stepId)}
  onStepComplete={(stepId, notes) => console.log('步骤完成:', stepId)}
  isHost={currentRole === 'arbitrator'}
/>
```

#### 特性
- 支持仲裁和调解两种程序类型
- 实时步骤跟踪和状态更新
- 子步骤展开和折叠
- 步骤备注和时间记录
- 权限控制（仲裁员可操作）

### 3. 角色特定界面 (RoleSpecificInterface)

#### 功能概述
为不同角色（仲裁员、当事人、证人）提供专门的交互界面和功能。

#### 使用方法
```typescript
import { RoleSpecificInterface } from '@/components/hearings/role-specific-interface';

<RoleSpecificInterface
  role="arbitrator" // 'arbitrator' | 'applicant' | 'respondent' | 'witness' | 'observer'
  hearingType="arbitration"
  isHost={true}
  onAction={(action, data) => {
    // 处理角色特定操作
    switch (action) {
      case 'raise-hand':
        // 处理举手发言
        break;
      case 'submit-evidence':
        // 处理证据提交
        break;
    }
  }}
/>
```

#### 角色功能
- **仲裁员**: 权限管理、程序控制、全员静音
- **当事人**: 举手发言、提交证据、查看材料
- **证人**: 请求发言、查看相关材料
- **旁听人**: 查看公开材料

### 4. 智能文书生成器 (SmartDocumentGenerator)

#### 功能概述
基于官方标准格式，智能生成各类法律文书。

#### 使用方法
```typescript
import { SmartDocumentGenerator } from '@/components/documents/smart-document-generator';

<SmartDocumentGenerator
  caseId="case-001"
  onDocumentGenerated={(documentId, content) => {
    // 处理生成的文书
  }}
/>
```

#### 支持的文书类型
- 仲裁申请书
- 仲裁答辩书
- 调解申请书
- 调解协议书
- 各类通知书

### 5. 公证处对接组件 (NotaryInterface)

#### 功能概述
完整的公证申请和管理流程，增强法律文件效力。

#### 使用方法
```typescript
import { NotaryInterface } from '@/components/notary/notary-interface';

<NotaryInterface
  caseId="case-001"
  documentId="doc-001"
  onNotaryComplete={(notaryId) => {
    // 处理公证完成
  }}
/>
```

#### 功能特性
- 公证申请提交
- 公证处选择
- 申请状态跟踪
- 公证书下载

### 6. 卷宗管理系统 (DossierSystem)

#### 功能概述
三位一体的卷宗管理：电子卷宗、纸质卷宗和电子印章。

#### 使用方法
```typescript
import { DossierSystem } from '@/components/mediation/dossier-system';

<DossierSystem
  mediationId="med-001"
  onDocumentUpdate={(documentId, status) => {
    // 处理文档状态更新
  }}
/>
```

#### 管理功能
- 电子文档上传、审批、归档
- 纸质文档位置管理
- 电子印章使用和验证
- 数字签名管理

### 7. 增强日程组件 (EnhancedCalendar)

#### 功能概述
多视图模式的日程管理组件，支持事件创建、编辑和提醒。

#### 使用方法
```typescript
import { EnhancedCalendar } from '@/components/schedule/enhanced-calendar';

<EnhancedCalendar
  events={events}
  onEventCreate={(event) => {
    // 处理事件创建
  }}
  onEventUpdate={(event) => {
    // 处理事件更新
  }}
  viewMode="timeline" // 'month' | 'week' | 'day' | 'list' | 'swimlane' | 'timeline'
/>
```

#### 视图模式
- **月视图**: 传统月历显示
- **周视图**: 周计划视图
- **日视图**: 详细日程安排
- **列表视图**: 事件列表形式
- **泳道视图**: 按时间段分组
- **时间轴视图**: 时间线展示

## 状态管理

### 1. AI消息状态 (ai-messages.ts)

#### 功能概述
AI助手消息的共享状态管理，支持悬浮助手和主页面的数据同步。

#### 使用方法
```typescript
import { useAIMessagesStore } from '@/store/ai-messages';

const {
  currentConversation,
  conversations,
  addMessage,
  createNewConversation,
  setIsTyping
} = useAIMessagesStore();
```

### 2. 案件状态管理 (useCasesStore)

#### 功能概述
案件数据的全局状态管理。

#### 使用方法
```typescript
import { useCasesStore } from '@/store';

const {
  cases,
  setCases,
  removeCase,
  duplicateCase
} = useCasesStore();
```

## 工具函数

### 1. 动画工具 (animation-utils.ts)

#### 功能概述
统一的动画工具类，确保全平台动画效果一致。

#### 使用方法
```typescript
import { fadeIn, slideUp, scaleIn } from '@/lib/animation-utils';

// 在组件中使用
<div className={fadeIn}>内容</div>
```

### 2. 会话超时管理 (useSessionTimeout)

#### 功能概述
提供30分钟会话超时保护。

#### 使用方法
```typescript
import { useSessionTimeout } from '@/hooks/useSessionTimeout';

// 在组件中使用
useSessionTimeout();
```

## 权限系统

### 角色识别机制
- 基于邮箱前缀识别仲裁员权限 (arb开头或包含arb@)
- 支持角色切换 (仲裁员/当事人/访客)
- 权限验证和访问控制

### 使用方法
```typescript
import { useRole } from '@/components/layout/role-switcher';

const { currentRole, switchRole } = useRole();

// 根据角色显示不同内容
if (currentRole === 'arbitrator') {
  // 仲裁员专用功能
}
```

## 最佳实践

### 1. 组件复用
- 优先使用现有组件
- 遵循统一的设计语言
- 保持组件的独立性和可复用性

### 2. 数据同步
- 使用数据同步系统进行模块间通信
- 及时发布和订阅相关事件
- 避免直接的组件间依赖

### 3. 状态管理
- 使用Zustand进行全局状态管理
- 保持状态的最小化和规范化
- 避免状态冗余和不一致

### 4. 错误处理
- 实现适当的错误边界
- 提供用户友好的错误信息
- 记录和监控错误情况

### 5. 性能优化
- 使用React.memo优化组件渲染
- 实现虚拟滚动处理大量数据
- 合理使用useCallback和useMemo

---

*最后更新: 2024年2月15日*
