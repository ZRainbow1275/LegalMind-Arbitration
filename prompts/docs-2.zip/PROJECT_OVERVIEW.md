# LegalMind 仲裁平台 - 项目概览

## 项目简介

LegalMind 是一个现代化的在线仲裁和调解平台，旨在为法律纠纷解决提供高效、智能、透明的数字化解决方案。平台集成了仲裁、调解、庭审、文档管理、AI智能助手等核心功能，为当事人、仲裁员、调解员提供全流程的在线服务。

## 核心设计理念

### 四大核心哲学
1. **Trust through Clarity (透明建立信任)** - 透明直观的用户界面，让用户清楚了解每个流程步骤
2. **Efficiency through Intelligence (智能提升效率)** - AI功能节省时间，自动化重复性工作
3. **Authority through Design (设计体现权威)** - 专业的视觉语言，体现法律服务的严肃性和权威性
4. **Innovation within Bounds (约束内的创新)** - 在法律框架内鼓励技术创新

### 开发原则
- **组件复用性** - 创建可复用的组件，确保设计的一致性
- **UI/UX精巧设计** - 统一的设计语言，优雅的动画效果，响应式布局
- **功能间的连通性** - 实现各模块间的数据同步和跳转连通
- **一致性和连贯性** - 保持开发语言设计的一致性连贯性

## 技术架构

### 前端技术栈
- **框架**: Next.js 14 (App Router)
- **语言**: TypeScript
- **UI组件**: shadcn/ui (基于 Radix UI)
- **样式**: Tailwind CSS
- **图标**: Lucide React
- **状态管理**: Zustand
- **数据获取**: TanStack React Query

### 核心功能模块

#### 1. 认证系统
- 基于邮箱前缀的仲裁员权限识别机制 (arb开头或包含arb@)
- useSessionTimeout hook 提供30分钟会话超时保护
- 角色切换功能 (仲裁员/当事人/访客)

#### 2. 仪表盘系统
- AI待办中心 - 智能任务管理和优先级排序
- 通知系统 - 支持智能数量显示(99+)和跳转连通
- 数据可视化 - 案件统计、进度跟踪、性能指标

#### 3. 案件管理系统
- 案件创建、编辑、删除、复制功能
- 高级筛选和搜索功能
- 案件状态跟踪和进度管理
- 智能文书生成集成

#### 4. 在线庭审系统
- 等候室作为庭审前置环节
- 视频会议集成
- 程序跟踪组件 (ProcedureTracker) - 支持仲裁和调解程序梳理
- 角色特定界面 (RoleSpecificInterface) - 为不同角色提供专门的交互功能
- 证据展示和质证功能

#### 5. 调解管理系统
- 案件关联系统 (case-relations.ts) - 调解申请与仲裁案件的双向互通
- 调解流程管理 (MediationProcess)
- 调解协议组件 (MediationAgreement) - 包括协议确认、在线签署
- 司法确认组件 (JudicialConfirmation)
- 强制执行组件 (EnforcementApplication)
- 公证处对接系统 (NotaryInterface)

#### 6. 卷宗管理系统
- 电子卷宗管理 - 支持文档上传、审批、归档
- 纸质卷宗管理 - 实体文档存储位置和状态管理
- 电子印章系统 - 机构印章、个人印章、司法印章管理
- 数字签名验证

#### 7. 日程安排系统
- 增强日程组件 (EnhancedCalendar) - 多种视图模式
- 泳道图视图 - 按时间段显示事件安排
- 时间轴视图 - 按日期和时间顺序显示事件
- 事件创建、编辑、提醒管理

#### 8. 消息系统
- 消息中心 - 支持消息分类、搜索、状态管理
- 仲裁员库消息连通 - 发送消息和预约咨询的跳转功能
- 实时通知推送

#### 9. AI智能助手系统
- 悬浮AI助手 - 球状悬浮和窗口状态的丝滑切换
- AI消息共享状态管理 (ai-messages.ts)
- 智能文书生成 - 基于官方标准格式的文书模板
- AI待办任务管理

#### 10. 数据同步系统
- 全平台模块间数据同步机制 (data-sync.ts)
- 事件驱动的状态更新
- 实时数据同步和冲突解决

## 核心组件库

### 通用组件
- **animation-utils.ts** - 统一的动画工具类
- **useSessionTimeout** - 会话超时管理
- **useDataSync** - 数据同步管理
- **RoleSwitcher** - 角色切换组件

### 业务组件
- **ProcedureTracker** - 程序跟踪组件
- **RoleSpecificInterface** - 角色特定界面组件
- **EnhancedCalendar** - 增强日程组件
- **SmartDocumentGenerator** - 智能文书生成组件
- **NotaryInterface** - 公证处对接组件
- **DossierSystem** - 卷宗管理系统

## 数据流架构

### 状态管理
- **Zustand Store** - 全局状态管理
- **案件状态** (useCasesStore) - 案件数据管理
- **AI消息状态** (ai-messages.ts) - AI助手消息管理
- **数据同步状态** (data-sync.ts) - 模块间同步管理

### 数据同步机制
- **事件驱动** - 基于事件的数据更新
- **模块注册** - 自动注册和注销模块
- **实时同步** - 跨模块的实时数据同步
- **冲突解决** - 数据冲突的自动处理

## 用户体验设计

### 动画系统
- 统一的过渡动画
- 微交互反馈
- 加载状态指示
- 响应式动画效果

### 响应式设计
- 移动端优先设计
- 多屏幕尺寸适配
- 触摸友好的交互
- 无障碍访问支持

### 主题系统
- 明暗主题切换
- 品牌色彩体系
- 一致的视觉语言
- 可定制的界面元素

## 安全性设计

### 身份认证
- 基于角色的访问控制 (RBAC)
- 会话超时保护
- 权限验证机制

### 数据安全
- 数字签名验证
- 电子印章管理
- 文档加密存储
- 审计日志记录

## 性能优化

### 前端优化
- 代码分割和懒加载
- 图片优化和压缩
- 缓存策略优化
- 虚拟滚动实现

### 数据优化
- 智能数据预取
- 增量数据更新
- 本地缓存机制
- 网络请求优化

## 部署和运维

### 开发环境
- 本地开发服务器
- 热重载支持
- 开发工具集成
- 调试和测试工具

### 生产环境
- 静态资源优化
- CDN 加速
- 监控和日志
- 错误追踪

## 未来规划

### 短期目标
- 移动端应用开发
- 更多AI功能集成
- 性能优化和稳定性提升
- 用户体验改进

### 长期目标
- 区块链技术集成
- 国际化支持
- 第三方系统集成
- 大数据分析平台

## 开发团队

### 技术栈专长
- React/Next.js 前端开发
- TypeScript 类型安全
- UI/UX 设计
- 法律科技产品设计

### 开发流程
- 敏捷开发方法
- 代码审查制度
- 自动化测试
- 持续集成/部署

## 项目文件结构

```
dev/
├── src/
│   ├── app/
│   │   ├── (private)/
│   │   │   ├── cases/              # 案件管理
│   │   │   ├── mediation/          # 调解管理
│   │   │   ├── hearings/           # 庭审管理
│   │   │   ├── schedule/           # 日程安排
│   │   │   ├── messages/           # 消息中心
│   │   │   ├── ai-assistant/       # AI智能助手
│   │   │   ├── arbitrators/        # 仲裁员库
│   │   │   └── dashboard/          # 仪表盘
│   │   └── layout.tsx              # 主布局
│   ├── components/
│   │   ├── hearings/               # 庭审相关组件
│   │   │   ├── procedure-tracker.tsx
│   │   │   └── role-specific-interface.tsx
│   │   ├── mediation/              # 调解相关组件
│   │   │   ├── mediation-agreement.tsx
│   │   │   ├── judicial-confirmation.tsx
│   │   │   ├── enforcement-application.tsx
│   │   │   └── dossier-system.tsx
│   │   ├── documents/              # 文档相关组件
│   │   │   └── smart-document-generator.tsx
│   │   ├── notary/                 # 公证相关组件
│   │   │   └── notary-interface.tsx
│   │   ├── schedule/               # 日程相关组件
│   │   │   └── enhanced-calendar.tsx
│   │   ├── ai/                     # AI相关组件
│   │   │   └── floating-ai-assistant.tsx
│   │   └── layout/                 # 布局组件
│   │       └── role-switcher.tsx
│   ├── lib/
│   │   ├── data-sync.ts            # 数据同步系统
│   │   └── animation-utils.ts      # 动画工具
│   ├── store/
│   │   ├── ai-messages.ts          # AI消息状态
│   │   └── index.ts                # 主状态管理
│   └── hooks/
│       ├── useSessionTimeout.ts    # 会话超时
│       └── useDataSync.ts          # 数据同步Hook
├── docs/
│   ├── PROJECT_OVERVIEW.md         # 项目概览
│   ├── COMPONENT_GUIDE.md          # 组件使用指南
│   └── API_REFERENCE.md            # API参考文档
└── README.md                       # 项目说明
```

## 开发和部署指南

### 开发环境设置
```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build

# 启动生产服务器
npm start
```

### 环境变量配置
```env
# .env.local
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_API_URL=http://localhost:3001
```

### 代码质量检查
```bash
# 类型检查
npm run type-check

# 代码格式化
npm run format

# 代码检查
npm run lint
```

---

*最后更新: 2024年2月15日*
*版本: v1.0.0*
*开发状态: 已完成*
