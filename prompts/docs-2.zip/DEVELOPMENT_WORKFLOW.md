# LegalMind 开发工作流程

## 概述

本文档定义了 LegalMind 仲裁平台的开发工作流程，确保团队协作的高效性和代码质量的一致性。

## 开发环境设置

### 1. 环境要求
- **Node.js**: >= 18.0.0
- **npm**: >= 9.0.0 或 **pnpm**: >= 8.0.0
- **Git**: >= 2.30.0
- **VSCode**: 推荐使用的IDE

### 2. 项目初始化
```bash
# 克隆项目
git clone https://github.com/legalmind/arbitration-platform.git
cd arbitration-platform

# 安装依赖
npm install
# 或
pnpm install

# 复制环境变量文件
cp .env.example .env.local

# 启动开发服务器
npm run dev
# 或
pnpm dev
```

### 3. VSCode 扩展推荐
```json
{
  "recommendations": [
    "bradlc.vscode-tailwindcss",
    "esbenp.prettier-vscode",
    "dbaeumer.vscode-eslint",
    "ms-vscode.vscode-typescript-next",
    "bradlc.vscode-tailwindcss",
    "formulahendry.auto-rename-tag",
    "christian-kohler.path-intellisense",
    "ms-vscode.vscode-json"
  ]
}
```

## Git 工作流程

### 1. 分支策略 (Git Flow)

```
main (生产分支)
├── develop (开发分支)
│   ├── feature/user-authentication
│   ├── feature/case-management
│   └── feature/online-hearing
├── release/v1.0.0 (发布分支)
└── hotfix/critical-bug-fix (热修复分支)
```

### 2. 分支命名规范
- **功能分支**: `feature/功能描述` (如 `feature/case-management`)
- **修复分支**: `bugfix/问题描述` (如 `bugfix/login-error`)
- **热修复分支**: `hotfix/紧急修复` (如 `hotfix/security-patch`)
- **发布分支**: `release/版本号` (如 `release/v1.0.0`)

### 3. 提交信息规范 (Conventional Commits)

```bash
# 格式
<type>(<scope>): <description>

[optional body]

[optional footer(s)]

# 类型说明
feat:     新功能
fix:      修复bug
docs:     文档更新
style:    代码格式调整
refactor: 代码重构
perf:     性能优化
test:     测试相关
chore:    构建过程或辅助工具的变动

# 示例
feat(auth): add JWT token authentication
fix(cases): resolve case status update issue
docs(api): update API documentation
style(ui): format button component code
refactor(store): restructure user state management
perf(query): optimize database query performance
test(auth): add unit tests for login function
chore(deps): update dependencies to latest versions
```

### 4. 工作流程步骤

#### 开始新功能开发
```bash
# 1. 切换到develop分支并拉取最新代码
git checkout develop
git pull origin develop

# 2. 创建功能分支
git checkout -b feature/case-management

# 3. 开发功能...

# 4. 提交代码
git add .
git commit -m "feat(cases): implement case creation functionality"

# 5. 推送分支
git push origin feature/case-management

# 6. 创建Pull Request到develop分支
```

#### 代码审查流程
```bash
# 1. 创建Pull Request
# 2. 自动运行CI/CD检查
# 3. 代码审查 (至少1人审查)
# 4. 解决审查意见
# 5. 合并到develop分支
# 6. 删除功能分支
```

## 代码质量控制

### 1. 代码检查工具配置

#### ESLint 配置 (.eslintrc.json)
```json
{
  "extends": [
    "next/core-web-vitals",
    "@typescript-eslint/recommended",
    "prettier"
  ],
  "rules": {
    "@typescript-eslint/no-unused-vars": "error",
    "@typescript-eslint/no-explicit-any": "warn",
    "prefer-const": "error",
    "no-var": "error"
  }
}
```

#### Prettier 配置 (.prettierrc)
```json
{
  "semi": true,
  "trailingComma": "es5",
  "singleQuote": true,
  "printWidth": 80,
  "tabWidth": 2,
  "useTabs": false
}
```

#### TypeScript 配置 (tsconfig.json)
```json
{
  "compilerOptions": {
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true
  }
}
```

### 2. 预提交钩子 (Husky + lint-staged)

#### package.json
```json
{
  "lint-staged": {
    "*.{js,jsx,ts,tsx}": [
      "eslint --fix",
      "prettier --write"
    ],
    "*.{json,md}": [
      "prettier --write"
    ]
  }
}
```

#### .husky/pre-commit
```bash
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"

npx lint-staged
npm run type-check
npm run test:staged
```

### 3. 代码审查清单

#### 功能性检查
- [ ] 功能是否按需求正确实现
- [ ] 边界条件是否正确处理
- [ ] 错误处理是否完善
- [ ] 性能是否满足要求

#### 代码质量检查
- [ ] 代码是否遵循项目规范
- [ ] 变量和函数命名是否清晰
- [ ] 代码是否有适当的注释
- [ ] 是否有重复代码需要重构

#### 安全性检查
- [ ] 输入验证是否充分
- [ ] 敏感信息是否正确处理
- [ ] 权限控制是否正确
- [ ] SQL注入等安全问题

#### 测试覆盖
- [ ] 是否有相应的单元测试
- [ ] 测试用例是否覆盖主要场景
- [ ] 集成测试是否通过
- [ ] 端到端测试是否通过

## 测试策略

### 1. 测试金字塔

```
    /\
   /  \     E2E Tests (少量)
  /____\    
 /      \   Integration Tests (适量)
/__________\ Unit Tests (大量)
```

### 2. 单元测试 (Jest + React Testing Library)

#### 测试文件结构
```
src/
├── components/
│   ├── Button/
│   │   ├── Button.tsx
│   │   ├── Button.test.tsx
│   │   └── index.ts
│   └── __tests__/
│       └── utils.test.ts
```

#### 测试示例
```typescript
// Button.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import { Button } from './Button';

describe('Button Component', () => {
  it('renders correctly', () => {
    render(<Button>Click me</Button>);
    expect(screen.getByRole('button')).toBeInTheDocument();
  });

  it('handles click events', () => {
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>Click me</Button>);
    
    fireEvent.click(screen.getByRole('button'));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('shows loading state', () => {
    render(<Button loading>Loading</Button>);
    expect(screen.getByRole('button')).toBeDisabled();
    expect(screen.getByText('Loading')).toBeInTheDocument();
  });
});
```

### 3. 集成测试

#### API 路由测试
```typescript
// api/cases.test.ts
import { createMocks } from 'node-mocks-http';
import handler from '../pages/api/cases';

describe('/api/cases', () => {
  it('returns cases list', async () => {
    const { req, res } = createMocks({
      method: 'GET',
      query: { page: '1', limit: '10' }
    });

    await handler(req, res);

    expect(res._getStatusCode()).toBe(200);
    const data = JSON.parse(res._getData());
    expect(data.success).toBe(true);
    expect(Array.isArray(data.data)).toBe(true);
  });
});
```

### 4. 端到端测试 (Playwright)

```typescript
// e2e/case-management.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Case Management', () => {
  test('user can create a new case', async ({ page }) => {
    await page.goto('/cases');
    
    // 点击创建案件按钮
    await page.click('[data-testid="create-case-button"]');
    
    // 填写表单
    await page.fill('[data-testid="case-title"]', '测试案件');
    await page.selectOption('[data-testid="case-type"]', 'commercial');
    await page.fill('[data-testid="case-amount"]', '100000');
    
    // 提交表单
    await page.click('[data-testid="submit-button"]');
    
    // 验证结果
    await expect(page.locator('[data-testid="success-message"]')).toBeVisible();
    await expect(page.locator('text=测试案件')).toBeVisible();
  });
});
```

## 持续集成/持续部署 (CI/CD)

### 1. GitHub Actions 工作流

#### .github/workflows/ci.yml
```yaml
name: CI

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Run linting
      run: npm run lint
    
    - name: Run type checking
      run: npm run type-check
    
    - name: Run unit tests
      run: npm run test:coverage
    
    - name: Run build
      run: npm run build
    
    - name: Upload coverage reports
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage/lcov.info

  e2e:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Install Playwright
      run: npx playwright install
    
    - name: Run E2E tests
      run: npm run test:e2e
    
    - name: Upload test results
      uses: actions/upload-artifact@v3
      if: failure()
      with:
        name: playwright-report
        path: playwright-report/
```

### 2. 部署流程

#### 开发环境部署
```yaml
name: Deploy to Development

on:
  push:
    branches: [ develop ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Deploy to Vercel
      uses: amondnet/vercel-action@v20
      with:
        vercel-token: ${{ secrets.VERCEL_TOKEN }}
        vercel-org-id: ${{ secrets.ORG_ID }}
        vercel-project-id: ${{ secrets.PROJECT_ID }}
        working-directory: ./
```

#### 生产环境部署
```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]
    tags: [ 'v*' ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Run security scan
      run: npm audit --audit-level high
    
    - name: Deploy to Production
      uses: amondnet/vercel-action@v20
      with:
        vercel-token: ${{ secrets.VERCEL_TOKEN }}
        vercel-org-id: ${{ secrets.ORG_ID }}
        vercel-project-id: ${{ secrets.PROJECT_ID }}
        vercel-args: '--prod'
        working-directory: ./
```

## 发布流程

### 1. 版本管理 (Semantic Versioning)

- **主版本号**: 不兼容的API修改
- **次版本号**: 向下兼容的功能性新增
- **修订号**: 向下兼容的问题修正

### 2. 发布检查清单

#### 发布前检查
- [ ] 所有功能测试通过
- [ ] 代码审查完成
- [ ] 文档更新完成
- [ ] 安全扫描通过
- [ ] 性能测试通过
- [ ] 数据库迁移脚本准备

#### 发布步骤
```bash
# 1. 创建发布分支
git checkout -b release/v1.1.0 develop

# 2. 更新版本号
npm version minor

# 3. 更新CHANGELOG.md
# 4. 提交发布准备
git commit -m "chore(release): prepare v1.1.0"

# 5. 合并到main分支
git checkout main
git merge release/v1.1.0

# 6. 创建标签
git tag v1.1.0

# 7. 推送到远程
git push origin main --tags

# 8. 合并回develop分支
git checkout develop
git merge main

# 9. 删除发布分支
git branch -d release/v1.1.0
```

### 3. 发布后监控

#### 监控指标
- 应用性能指标 (响应时间、错误率)
- 用户行为指标 (活跃用户、功能使用率)
- 系统资源指标 (CPU、内存、磁盘使用率)
- 业务指标 (案件创建数、庭审完成率)

#### 回滚计划
```bash
# 快速回滚到上一个版本
git checkout main
git revert HEAD
git push origin main

# 或回滚到特定版本
git reset --hard v1.0.0
git push origin main --force
```

## 团队协作规范

### 1. 代码审查规范

#### 审查者职责
- 检查代码质量和规范
- 验证功能实现正确性
- 提供建设性反馈
- 确保测试覆盖充分

#### 作者职责
- 提供清晰的PR描述
- 响应审查意见
- 保持代码更新
- 确保CI检查通过

### 2. 沟通协作

#### 日常沟通
- 每日站会 (15分钟)
- 周度回顾会议
- 月度技术分享
- 季度架构评审

#### 文档维护
- 及时更新技术文档
- 记录重要决策
- 分享最佳实践
- 维护知识库

### 3. 知识分享

#### 技术分享主题
- 新技术调研
- 性能优化经验
- 问题解决方案
- 最佳实践总结

#### 文档类型
- 技术设计文档
- API接口文档
- 部署运维文档
- 故障处理手册

---

*本工作流程将随着团队发展和项目需求持续优化，确保开发效率和代码质量的平衡。*
