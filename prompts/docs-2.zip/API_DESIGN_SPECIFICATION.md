# LegalMind 仲裁平台 API 设计规范

**文档版本**: Version 0.5
**完成日期**: 2025年8月22日
**项目负责人**: 方寒（独立开发者）
**项目状态**: 前端原型已完成，准备全栈开发

## 1. API 设计概述

本文档基于LegalMind仲裁平台前端原型的深度分析，定义了完整的API设计标准，确保前后端、移动端、小程序等多端开发的一致性、可维护性和可扩展性。

### 1.1 设计原则

#### RESTful 设计标准
- 使用标准 HTTP 方法 (GET, POST, PUT, DELETE, PATCH)
- 资源导向的 URL 设计
- 无状态的请求处理
- 统一的接口规范
- 幂等性保证

#### 一致性原则
- 统一的命名规范（camelCase for JSON, kebab-case for URLs）
- 一致的响应格式（标准化的成功和错误响应）
- 标准化的错误处理（HTTP状态码 + 业务错误码）
- 统一的认证机制（JWT + RBAC）
- 统一的分页和排序规范

#### 安全性原则
- 输入验证和清理（XSS防护、SQL注入防护）
- 输出编码和转义
- 访问控制和权限验证（基于角色的访问控制）
- 敏感数据保护（数据脱敏、加密传输）
- API限流和防刷机制

### 1.2 URL 设计规范

#### 基础结构
```
https://api.legalmind.com/v1/{resource}
```

#### 资源命名规范
- 使用复数名词: `/cases`, `/arbitrators`, `/documents`, `/mediations`
- 使用小写字母和连字符: `/hearing-records`, `/case-documents`, `/ai-assistants`
- 避免动词: 使用 HTTP 方法表示操作
- 版本控制: 在URL中包含版本号 `/v1/`, `/v2/`

#### 嵌套资源设计
```
GET /cases/{caseId}/documents                    # 获取案件文档列表
POST /cases/{caseId}/documents                   # 创建案件文档
GET /cases/{caseId}/documents/{documentId}       # 获取特定文档
PUT /cases/{caseId}/documents/{documentId}       # 更新文档
DELETE /cases/{caseId}/documents/{documentId}    # 删除文档

GET /cases/{caseId}/hearings                     # 获取案件庭审记录
POST /cases/{caseId}/hearings                    # 创建庭审记录
GET /hearings/{hearingId}/participants           # 获取庭审参与者
POST /hearings/{hearingId}/participants          # 添加参与者

GET /arbitrators/{id}/appointments               # 获取仲裁员预约
POST /arbitrators/{id}/appointments              # 创建仲裁员预约
GET /arbitrators/{id}/cases                      # 获取仲裁员案件列表

GET /mediations/{mediationId}/agreements         # 获取调解协议
POST /mediations/{mediationId}/agreements        # 创建调解协议
PUT /mediations/{mediationId}/agreements/{id}    # 更新调解协议
```

## 2. 标准响应格式

### 2.1 成功响应格式
```typescript
interface APISuccessResponse<T> {
  success: true;
  data: T;
  meta?: {
    total?: number;           // 总记录数（分页时）
    page?: number;            // 当前页码
    limit?: number;           // 每页数量
    hasNext?: boolean;        // 是否有下一页
    hasPrev?: boolean;        // 是否有上一页
    timestamp: string;        // 响应时间戳
    requestId: string;        // 请求追踪ID
  };
}

// 示例：获取案件列表
{
  "success": true,
  "data": [
    {
      "id": "case-001",
      "caseNumber": "赣仲2024第0001号",
      "title": "建设工程合同纠纷案",
      "status": "hearing_scheduled",
      "disputeAmount": 500000,
      "createdAt": "2024-01-15T09:00:00Z",
      "updatedAt": "2024-02-15T14:30:00Z"
    }
  ],
  "meta": {
    "total": 156,
    "page": 1,
    "limit": 20,
    "hasNext": true,
    "hasPrev": false,
    "timestamp": "2024-02-15T15:30:00Z",
    "requestId": "req-12345-abcde"
  }
}
```

### 2.2 错误响应格式
```typescript
interface APIErrorResponse {
  success: false;
  error: {
    code: string;             // 业务错误码
    message: string;          // 错误描述
    details?: any;            // 详细错误信息
    field?: string;           // 字段级错误（表单验证）
    timestamp: string;        // 错误时间戳
    requestId: string;        // 请求追踪ID
  };
}

// 示例：验证错误
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "输入数据验证失败",
    "details": {
      "email": ["邮箱格式不正确"],
      "phone": ["手机号码不能为空"]
    },
    "timestamp": "2024-02-15T15:30:00Z",
    "requestId": "req-12345-abcde"
  }
}
```

### 2.3 HTTP状态码规范
| 状态码 | 含义 | 使用场景 | 业务错误码示例 |
|-------|------|---------|---------------|
| 200 | 成功 | 获取数据成功、更新成功 | - |
| 201 | 创建成功 | 资源创建成功 | - |
| 204 | 无内容 | 删除成功、更新成功（无返回数据） | - |
| 400 | 请求错误 | 参数验证失败、业务规则违反 | VALIDATION_ERROR, BUSINESS_RULE_VIOLATION |
| 401 | 未认证 | 未登录、token过期 | UNAUTHORIZED, TOKEN_EXPIRED |
| 403 | 禁止访问 | 权限不足 | FORBIDDEN, INSUFFICIENT_PERMISSIONS |
| 404 | 资源不存在 | 请求的资源不存在 | RESOURCE_NOT_FOUND |
| 409 | 冲突 | 资源冲突、重复操作 | RESOURCE_CONFLICT, DUPLICATE_OPERATION |
| 422 | 实体错误 | 语义错误、业务逻辑错误 | SEMANTIC_ERROR, BUSINESS_LOGIC_ERROR |
| 429 | 请求过多 | 限流触发 | RATE_LIMIT_EXCEEDED |
| 500 | 服务器错误 | 内部服务器错误 | INTERNAL_SERVER_ERROR |
| 502 | 网关错误 | 上游服务错误 | UPSTREAM_SERVICE_ERROR |
| 503 | 服务不可用 | 服务维护、过载 | SERVICE_UNAVAILABLE |

## 3. 认证授权规范

### 3.1 JWT Token 设计
```typescript
interface JWTPayload {
  sub: string;              // 用户ID
  email: string;            // 用户邮箱
  role: string;             // 用户角色 (arbitrator|applicant|respondent|admin)
  permissions: string[];    // 权限列表
  iat: number;              // 签发时间
  exp: number;              // 过期时间
  jti: string;              // Token ID
}

// 请求头格式
Authorization: Bearer <JWT_TOKEN>
```

### 3.2 权限控制矩阵
| 资源/操作 | 申请人 | 被申请人 | 仲裁员 | 管理员 | 说明 |
|----------|-------|---------|-------|-------|------|
| 案件创建 | ✓ | ✗ | ✗ | ✓ | 申请人可创建案件 |
| 案件查看 | ✓(自己的) | ✓(相关的) | ✓(分配的) | ✓ | 基于关联关系 |
| 案件编辑 | ✓(草稿状态) | ✗ | ✗ | ✓ | 限制编辑条件 |
| 文档上传 | ✓ | ✓ | ✓ | ✓ | 所有角色可上传 |
| 庭审主持 | ✗ | ✗ | ✓ | ✓ | 仲裁员专有权限 |
| 系统配置 | ✗ | ✗ | ✗ | ✓ | 管理员专有 |

### 3.3 API安全机制
```typescript
// 请求签名验证（敏感操作）
interface RequestSignature {
  timestamp: string;        // 请求时间戳
  nonce: string;           // 随机数
  signature: string;       // 签名值 = HMAC-SHA256(timestamp + nonce + body, secret)
}

// 限流配置
interface RateLimitConfig {
  windowMs: number;        // 时间窗口（毫秒）
  maxRequests: number;     // 最大请求数
  skipSuccessfulRequests: boolean;  // 是否跳过成功请求
  skipFailedRequests: boolean;      // 是否跳过失败请求
}

// 不同接口的限流策略
const rateLimits = {
  '/auth/login': { windowMs: 900000, maxRequests: 5 },      // 15分钟5次
  '/auth/register': { windowMs: 3600000, maxRequests: 3 },  // 1小时3次
  '/cases': { windowMs: 60000, maxRequests: 100 },          // 1分钟100次
  '/documents/upload': { windowMs: 60000, maxRequests: 10 }, // 1分钟10次
};
```

## 4. 核心API接口定义

### 4.1 用户认证接口

#### 用户注册
```http
POST /v1/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "phone": "+86-13800138000",
  "password": "SecurePassword123!",
  "userType": "individual",
  "verificationCode": "123456"
}

Response 201:
{
  "success": true,
  "data": {
    "userId": "user-12345",
    "email": "user@example.com",
    "userType": "individual",
    "status": "pending_verification"
  }
}
```

#### 用户登录
```http
POST /v1/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePassword123!"
}

Response 200:
{
  "success": true,
  "data": {
    "accessToken": "eyJhbGciOiJSUzI1NiIs...",
    "refreshToken": "rt_1234567890abcdef",
    "expiresIn": 7200,
    "user": {
      "id": "user-12345",
      "email": "user@example.com",
      "role": "applicant",
      "permissions": ["case:read", "case:create", "document:upload"]
    }
  }
}
```

#### 实名认证
```http
POST /v1/auth/verification
Content-Type: multipart/form-data
Authorization: Bearer <token>

{
  "realName": "张三",
  "idNumber": "110101199001011234",
  "idCardFront": <file>,
  "idCardBack": <file>,
  "faceImage": <file>
}

Response 200:
{
  "success": true,
  "data": {
    "verificationId": "verify-12345",
    "status": "processing",
    "estimatedTime": "2-5分钟"
  }
}
```

### 4.2 案件管理接口

#### 创建案件
```http
POST /v1/cases
Content-Type: application/json
Authorization: Bearer <token>

{
  "title": "建设工程合同纠纷案",
  "caseType": "contract_dispute",
  "disputeAmount": 500000,
  "respondentInfo": {
    "name": "某建设公司",
    "contact": "contact@company.com",
    "address": "北京市朝阳区某某路123号"
  },
  "disputeDescription": "关于工程款支付争议...",
  "arbitrationAgreement": "doc-agreement-123"
}

Response 201:
{
  "success": true,
  "data": {
    "id": "case-12345",
    "caseNumber": "赣仲2024第0001号",
    "status": "draft",
    "createdAt": "2024-02-15T09:00:00Z",
    "estimatedFee": 25000
  }
}
```

#### 获取案件列表
```http
GET /v1/cases?page=1&limit=20&status=active&keyword=合同
Authorization: Bearer <token>

Response 200:
{
  "success": true,
  "data": [
    {
      "id": "case-12345",
      "caseNumber": "赣仲2024第0001号",
      "title": "建设工程合同纠纷案",
      "status": "hearing_scheduled",
      "disputeAmount": 500000,
      "applicant": {
        "id": "user-123",
        "name": "张三",
        "type": "individual"
      },
      "respondent": {
        "name": "某建设公司",
        "type": "enterprise"
      },
      "arbitrators": [
        {
          "id": "arb-001",
          "name": "李仲裁",
          "role": "presiding"
        }
      ],
      "nextHearing": "2024-02-20T14:00:00Z",
      "createdAt": "2024-01-15T09:00:00Z",
      "updatedAt": "2024-02-15T14:30:00Z"
    }
  ],
  "meta": {
    "total": 156,
    "page": 1,
    "limit": 20,
    "hasNext": true
  }
}
```

#### 更新案件状态
```http
PATCH /v1/cases/{caseId}/status
Content-Type: application/json
Authorization: Bearer <token>

{
  "status": "hearing_scheduled",
  "reason": "仲裁庭已组成，安排庭审时间",
  "scheduledDate": "2024-02-20T14:00:00Z"
}

Response 200:
{
  "success": true,
  "data": {
    "id": "case-12345",
    "status": "hearing_scheduled",
    "statusHistory": [
      {
        "status": "hearing_scheduled",
        "timestamp": "2024-02-15T15:30:00Z",
        "operator": "admin-001",
        "reason": "仲裁庭已组成，安排庭审时间"
      }
    ]
  }
}
```

### 4.3 文档管理接口

#### 上传文档
```http
POST /v1/cases/{caseId}/documents
Content-Type: multipart/form-data
Authorization: Bearer <token>

{
  "file": <file>,
  "documentType": "evidence",
  "category": "contract",
  "title": "建设工程合同",
  "description": "双方签署的建设工程合同原件"
}

Response 201:
{
  "success": true,
  "data": {
    "id": "doc-12345",
    "fileName": "contract.pdf",
    "fileSize": 2048576,
    "documentType": "evidence",
    "category": "contract",
    "uploadedAt": "2024-02-15T15:30:00Z",
    "downloadUrl": "https://files.legalmind.com/docs/doc-12345",
    "previewUrl": "https://preview.legalmind.com/docs/doc-12345"
  }
}
```

#### 获取文档列表
```http
GET /v1/cases/{caseId}/documents?type=evidence&category=contract
Authorization: Bearer <token>

Response 200:
{
  "success": true,
  "data": [
    {
      "id": "doc-12345",
      "fileName": "contract.pdf",
      "title": "建设工程合同",
      "documentType": "evidence",
      "category": "contract",
      "fileSize": 2048576,
      "uploadedBy": {
        "id": "user-123",
        "name": "张三",
        "role": "applicant"
      },
      "uploadedAt": "2024-02-15T15:30:00Z",
      "status": "approved",
      "downloadCount": 5
    }
  ]
}
```
```

### 4. 查询参数
```
GET /cases?status=active&page=1&limit=20&sort=createdAt:desc
GET /arbitrators?specialty=commercial&location=beijing&available=true
GET /documents?caseId=123&type=evidence&dateFrom=2024-01-01
```

## HTTP 方法规范

### GET - 获取资源
```typescript
// 获取资源列表
GET /api/cases
Response: {
  data: Case[],
  pagination: PaginationInfo,
  filters: FilterInfo
}

// 获取单个资源
GET /api/cases/{id}
Response: {
  data: Case
}
```

### POST - 创建资源
```typescript
POST /api/cases
Request: {
  title: string,
  type: CaseType,
  amount: number,
  parties: PartyInfo[]
}
Response: {
  data: Case,
  message: "案件创建成功"
}
```

### PUT - 完整更新资源
```typescript
PUT /api/cases/{id}
Request: {
  title: string,
  type: CaseType,
  amount: number,
  parties: PartyInfo[]
}
Response: {
  data: Case,
  message: "案件更新成功"
}
```

### PATCH - 部分更新资源
```typescript
PATCH /api/cases/{id}
Request: {
  status: "in_progress"
}
Response: {
  data: Case,
  message: "案件状态更新成功"
}
```

### DELETE - 删除资源
```typescript
DELETE /api/cases/{id}
Response: {
  message: "案件删除成功"
}
```

## 响应格式规范

### 1. 成功响应
```typescript
interface SuccessResponse<T> {
  success: true;
  data: T;
  message?: string;
  meta?: {
    timestamp: string;
    requestId: string;
    version: string;
  };
}

// 列表响应
interface ListResponse<T> {
  success: true;
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
  filters?: Record<string, any>;
  sorting?: {
    field: string;
    direction: 'asc' | 'desc';
  };
}
```

### 2. 错误响应
```typescript
interface ErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: any;
    field?: string; // 字段级错误
  };
  meta: {
    timestamp: string;
    requestId: string;
    version: string;
  };
}

// 验证错误响应
interface ValidationErrorResponse {
  success: false;
  error: {
    code: 'VALIDATION_ERROR';
    message: '输入验证失败';
    details: {
      field: string;
      message: string;
      value: any;
    }[];
  };
}
```

## 状态码规范

### 2xx 成功状态码
- `200 OK`: 请求成功
- `201 Created`: 资源创建成功
- `202 Accepted`: 请求已接受，正在处理
- `204 No Content`: 请求成功，无返回内容

### 4xx 客户端错误
- `400 Bad Request`: 请求参数错误
- `401 Unauthorized`: 未认证
- `403 Forbidden`: 无权限访问
- `404 Not Found`: 资源不存在
- `409 Conflict`: 资源冲突
- `422 Unprocessable Entity`: 请求格式正确但语义错误
- `429 Too Many Requests`: 请求频率超限

### 5xx 服务器错误
- `500 Internal Server Error`: 服务器内部错误
- `502 Bad Gateway`: 网关错误
- `503 Service Unavailable`: 服务不可用
- `504 Gateway Timeout`: 网关超时

## 认证和授权

### 1. JWT Token 认证
```typescript
// 登录请求
POST /api/auth/login
Request: {
  email: string,
  password: string
}
Response: {
  success: true,
  data: {
    user: UserInfo,
    token: string,
    refreshToken: string,
    expiresIn: number
  }
}

// 请求头
Authorization: Bearer {jwt_token}
```

### 2. 权限验证
```typescript
// 权限检查中间件
interface Permission {
  resource: string;
  action: 'create' | 'read' | 'update' | 'delete';
  conditions?: Record<string, any>;
}

// 角色权限映射
const rolePermissions = {
  user: [
    { resource: 'cases', action: 'read', conditions: { ownerId: 'self' } },
    { resource: 'cases', action: 'create' }
  ],
  arbitrator: [
    { resource: 'cases', action: 'read' },
    { resource: 'hearings', action: 'create' },
    { resource: 'hearings', action: 'update' }
  ],
  admin: [
    { resource: '*', action: '*' }
  ]
};
```

## 数据验证规范

### 1. 输入验证 (Zod Schema)
```typescript
import { z } from 'zod';

// 案件创建验证
const createCaseSchema = z.object({
  title: z.string().min(1, '案件标题不能为空').max(200, '案件标题过长'),
  type: z.enum(['commercial', 'labor', 'intellectual_property']),
  amount: z.number().positive('争议金额必须为正数'),
  description: z.string().optional(),
  parties: z.array(z.object({
    name: z.string().min(1, '当事人姓名不能为空'),
    type: z.enum(['applicant', 'respondent']),
    contact: z.object({
      email: z.string().email('邮箱格式不正确'),
      phone: z.string().regex(/^1[3-9]\d{9}$/, '手机号格式不正确')
    })
  })).min(2, '至少需要两个当事人')
});

// API 路由中使用
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const validatedData = createCaseSchema.parse(body);
    
    // 处理业务逻辑
    const case = await createCase(validatedData);
    
    return NextResponse.json({
      success: true,
      data: case,
      message: '案件创建成功'
    }, { status: 201 });
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: '输入验证失败',
          details: error.errors.map(err => ({
            field: err.path.join('.'),
            message: err.message,
            value: err.input
          }))
        }
      }, { status: 422 });
    }
    
    // 其他错误处理
    return NextResponse.json({
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: '服务器内部错误'
      }
    }, { status: 500 });
  }
}
```

### 2. 输出验证
```typescript
// 响应数据验证
const caseResponseSchema = z.object({
  id: z.string(),
  title: z.string(),
  caseNumber: z.string(),
  status: z.enum(['draft', 'submitted', 'in_progress', 'completed']),
  type: z.string(),
  amount: z.number(),
  createdAt: z.string(),
  updatedAt: z.string()
});

// 确保响应数据符合规范
const sanitizedCase = caseResponseSchema.parse(rawCaseData);
```

## 分页和排序

### 1. 分页参数
```typescript
interface PaginationParams {
  page?: number;     // 页码，从1开始
  limit?: number;    // 每页数量，默认20，最大100
  offset?: number;   // 偏移量，可选
}

// 查询示例
GET /api/cases?page=1&limit=20
```

### 2. 排序参数
```typescript
interface SortingParams {
  sort?: string;     // 排序字段
  order?: 'asc' | 'desc'; // 排序方向
}

// 查询示例
GET /api/cases?sort=createdAt&order=desc
GET /api/cases?sort=amount:asc,createdAt:desc  // 多字段排序
```

### 3. 分页响应
```typescript
interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
  links: {
    first: string;
    prev?: string;
    next?: string;
    last: string;
  };
}
```

## 过滤和搜索

### 1. 基础过滤
```typescript
// 等值过滤
GET /api/cases?status=active&type=commercial

// 范围过滤
GET /api/cases?amount_gte=10000&amount_lte=100000
GET /api/cases?created_after=2024-01-01&created_before=2024-12-31

// 包含过滤
GET /api/cases?status_in=active,pending&type_not_in=labor
```

### 2. 文本搜索
```typescript
// 全文搜索
GET /api/cases?search=合同纠纷

// 字段搜索
GET /api/cases?title_contains=建设工程&description_contains=违约
```

### 3. 复杂过滤
```typescript
// 使用查询对象
POST /api/cases/search
Request: {
  filters: {
    status: { in: ['active', 'pending'] },
    amount: { gte: 10000, lte: 100000 },
    createdAt: { after: '2024-01-01' },
    parties: {
      some: {
        name: { contains: '公司' }
      }
    }
  },
  search: '合同纠纷',
  sort: [
    { field: 'amount', direction: 'desc' },
    { field: 'createdAt', direction: 'desc' }
  ],
  pagination: {
    page: 1,
    limit: 20
  }
}
```

## 错误处理规范

### 1. 错误代码定义
```typescript
enum ErrorCode {
  // 通用错误
  INTERNAL_ERROR = 'INTERNAL_ERROR',
  VALIDATION_ERROR = 'VALIDATION_ERROR',
  NOT_FOUND = 'NOT_FOUND',
  UNAUTHORIZED = 'UNAUTHORIZED',
  FORBIDDEN = 'FORBIDDEN',
  
  // 业务错误
  CASE_NOT_FOUND = 'CASE_NOT_FOUND',
  CASE_ALREADY_SUBMITTED = 'CASE_ALREADY_SUBMITTED',
  ARBITRATOR_NOT_AVAILABLE = 'ARBITRATOR_NOT_AVAILABLE',
  HEARING_TIME_CONFLICT = 'HEARING_TIME_CONFLICT',
  
  // 系统错误
  DATABASE_ERROR = 'DATABASE_ERROR',
  EXTERNAL_SERVICE_ERROR = 'EXTERNAL_SERVICE_ERROR',
  RATE_LIMIT_EXCEEDED = 'RATE_LIMIT_EXCEEDED'
}
```

### 2. 错误处理中间件
```typescript
export function errorHandler(error: Error, request: Request) {
  const requestId = generateRequestId();
  
  // 记录错误日志
  logger.error('API Error', {
    requestId,
    error: error.message,
    stack: error.stack,
    url: request.url,
    method: request.method
  });
  
  // 根据错误类型返回相应响应
  if (error instanceof ValidationError) {
    return NextResponse.json({
      success: false,
      error: {
        code: ErrorCode.VALIDATION_ERROR,
        message: error.message,
        details: error.details
      },
      meta: {
        requestId,
        timestamp: new Date().toISOString()
      }
    }, { status: 422 });
  }
  
  if (error instanceof NotFoundError) {
    return NextResponse.json({
      success: false,
      error: {
        code: ErrorCode.NOT_FOUND,
        message: error.message
      },
      meta: {
        requestId,
        timestamp: new Date().toISOString()
      }
    }, { status: 404 });
  }
  
  // 默认服务器错误
  return NextResponse.json({
    success: false,
    error: {
      code: ErrorCode.INTERNAL_ERROR,
      message: '服务器内部错误'
    },
    meta: {
      requestId,
      timestamp: new Date().toISOString()
    }
  }, { status: 500 });
}
```

## 版本控制

### 1. URL 版本控制
```typescript
// 版本在 URL 中
GET /api/v1/cases
GET /api/v2/cases

// 版本在头部
GET /api/cases
Headers: {
  'API-Version': 'v1'
}
```

### 2. 向后兼容性
```typescript
// 字段废弃标记
interface CaseResponse {
  id: string;
  title: string;
  /** @deprecated 使用 caseNumber 替代 */
  number?: string;
  caseNumber: string;
}

// 版本适配器
function adaptCaseResponseV1(caseV2: CaseV2): CaseV1 {
  return {
    ...caseV2,
    number: caseV2.caseNumber // 向后兼容
  };
}
```

## 性能优化

### 1. 缓存策略
```typescript
// 响应缓存头
export async function GET(request: Request) {
  const cases = await getCases();
  
  return NextResponse.json(cases, {
    headers: {
      'Cache-Control': 'public, max-age=300', // 5分钟缓存
      'ETag': generateETag(cases)
    }
  });
}

// 条件请求支持
if (request.headers.get('If-None-Match') === etag) {
  return new NextResponse(null, { status: 304 });
}
```

### 2. 数据预加载
```typescript
// 关联数据预加载
GET /api/cases?include=documents,hearings,parties

// 字段选择
GET /api/cases?fields=id,title,status,amount
```

### 3. 批量操作
```typescript
// 批量创建
POST /api/cases/batch
Request: {
  cases: [
    { title: '案件1', type: 'commercial' },
    { title: '案件2', type: 'labor' }
  ]
}

// 批量更新
PATCH /api/cases/batch
Request: {
  updates: [
    { id: '1', status: 'active' },
    { id: '2', status: 'completed' }
  ]
}
```

## API 文档规范

### 1. OpenAPI 规范
```yaml
openapi: 3.0.0
info:
  title: LegalMind API
  version: 1.0.0
  description: LegalMind 仲裁平台 API

paths:
  /cases:
    get:
      summary: 获取案件列表
      parameters:
        - name: page
          in: query
          schema:
            type: integer
            default: 1
        - name: limit
          in: query
          schema:
            type: integer
            default: 20
            maximum: 100
      responses:
        '200':
          description: 成功获取案件列表
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/CaseListResponse'
```

### 2. 代码注释
```typescript
/**
 * 获取案件列表
 * 
 * @route GET /api/cases
 * @param {number} page - 页码，从1开始
 * @param {number} limit - 每页数量，默认20，最大100
 * @param {string} status - 案件状态过滤
 * @param {string} search - 搜索关键词
 * @returns {Promise<CaseListResponse>} 案件列表响应
 * 
 * @example
 * ```
 * GET /api/cases?page=1&limit=20&status=active&search=合同
 * ```
 */
export async function GET(request: Request) {
  // 实现逻辑
}
```

---

*本规范将随着项目发展持续更新，确保 API 设计的一致性和最佳实践。*
