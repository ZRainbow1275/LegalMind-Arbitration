# 在线庭审系统 API 合同（草案）

面向前后端协同的接口契约草拟，覆盖“争议焦点（focus）”与“证人管理（witness）”。

## 约定
- Base URL: /api
- 认证：Bearer {token}
- 通用响应
{
  "success": boolean,
  "data"?: any,
  "error"?: { code: string, message: string }
}
- 分页：?page=1&pageSize=20

---

## 一、争议焦点 Focus

实体 Focus
{
  id: string,
  caseId: string,
  title: string,           // 焦点名称（如：是否违约、金额差异）
  description?: string,    // 说明
  relatedEvidenceIds?: string[],
  relatedTranscriptIds?: string[],
  status: 'open' | 'in-review' | 'closed',
  createdBy: string,       // 用户ID
  createdAt: string,       // ISO
  updatedAt: string        // ISO
}

1) 创建焦点
POST /focus
body: { caseId, title, description?, relatedEvidenceIds?, relatedTranscriptIds? }
return: { success, data: Focus }

2) 更新焦点
PATCH /focus/:id
body: { title?, description?, relatedEvidenceIds?, relatedTranscriptIds?, status? }
return: { success, data: Focus }

3) 标记为关键/取消关键（可选）
POST /focus/:id/mark
body: { key: boolean }
return: { success }

4) 推送至合议通道
POST /focus/:id/push-tribunal
body: { note?: string }
return: { success }

5) 列表与查询
GET /cases/:caseId/focus?status=open|in-review|closed&page=1&pageSize=20
return: { success, data: { items: Focus[], total: number } }

---

## 二、证人 Witness

实体 Witness
{
  id: string,
  caseId: string,
  name: string,
  status: 'waiting' | 'in-court' | 'removed',
  invitedAt?: string,
  removedAt?: string
}

1) 等候室列表
GET /cases/:caseId/witnesses?status=waiting
return: { success, data: Witness[] }

2) 邀请入庭
POST /witness/invite
body: { caseId, witnessId }
return: { success, data: Witness }

3) 请出法庭
POST /witness/remove
body: { caseId, witnessId, reason?: string }
return: { success, data: Witness }

4) 状态更新（泛化）
PATCH /witness/:id
body: { status }
return: { success, data: Witness }

5) 历史记录（审计）
GET /witness/audit?caseId=xxx
return: { success, data: Array<{ id:string, witnessId:string, action:'invite'|'remove'|'update', by:string, at:string, detail?:string }> }

---

## 三、实时与订阅（预留）
- SSE/WebSocket: /realtime?caseId=xxx
- 主题：focus.updated、witness.updated、hearing.phase、speaking.changed
- 负载：与上文实体保持一致，附加 { ts } 字段

## 四、错误码（示例）
- AUTH-001 未授权
- DATA-404 资源不存在
- VALID-400 参数不合法
- CONFLICT-409 状态冲突

## 五、扩展点
- Focus 支持优先级、来源（AI/人工）、与仲裁意见的关联
- Witness 支持实名与证件信息、合规与留痕策略

