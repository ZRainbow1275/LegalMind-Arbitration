# LegalMind 仲裁平台数据库设计文档

**文档版本**: Version 0.5  
**完成日期**: 2025年8月22日  
**项目负责人**: 方寒（独立开发者）  
**项目状态**: 前端原型已完成，准备全栈开发  

## 1. 数据库架构概述

### 1.1 技术选型
- **主数据库**: PostgreSQL 15.0+
- **缓存数据库**: Redis 7.0+
- **搜索引擎**: Elasticsearch 8.0+
- **文件存储**: MinIO (S3兼容)
- **ORM框架**: Prisma 5.0+

### 1.2 数据库分层设计
```
┌─────────────────────────────────────────────────────────────┐
│                        应用层                                │
│                   (NestJS + Prisma)                        │
└─────────────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────────────┐
│                        缓存层                                │
│                      (Redis)                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │ 会话缓存    │  │ 数据缓存    │  │ 消息队列    │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
└─────────────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────────────┐
│                        持久层                                │
│                   (PostgreSQL)                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │ 业务数据库  │  │ 日志数据库  │  │ 分析数据库  │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
└─────────────────────────────────────────────────────────────┘
```

## 2. 核心数据模型设计

### 2.1 用户相关表结构

#### users (用户基础信息表)
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    user_type user_type_enum NOT NULL, -- 'individual', 'enterprise'
    status user_status_enum DEFAULT 'active', -- 'active', 'inactive', 'suspended'
    email_verified BOOLEAN DEFAULT FALSE,
    phone_verified BOOLEAN DEFAULT FALSE,
    last_login_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_created_at ON users(created_at);
```

#### user_profiles (用户详细信息表)
```sql
CREATE TABLE user_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    profile_type profile_type_enum NOT NULL, -- 'individual', 'enterprise'
    
    -- 个人用户字段
    real_name VARCHAR(100),
    id_number VARCHAR(18),
    id_card_front_url TEXT,
    id_card_back_url TEXT,
    face_verification_data TEXT,
    
    -- 企业用户字段
    company_name VARCHAR(200),
    business_license VARCHAR(50),
    legal_representative VARCHAR(100),
    legal_rep_id_number VARCHAR(18),
    company_address TEXT,
    
    -- 通用字段
    verification_status verification_status_enum DEFAULT 'pending', -- 'pending', 'verified', 'rejected'
    verification_documents JSONB,
    verified_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX idx_user_profiles_verification_status ON user_profiles(verification_status);
```

#### user_roles (用户角色表)
```sql
CREATE TABLE user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role role_enum NOT NULL, -- 'applicant', 'respondent', 'arbitrator', 'mediator', 'admin'
    permissions JSONB, -- 权限列表
    is_active BOOLEAN DEFAULT TRUE,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    assigned_by UUID REFERENCES users(id)
);

CREATE INDEX idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX idx_user_roles_role ON user_roles(role);
```

### 2.2 案件相关表结构

#### arbitration_cases (仲裁案件表)
```sql
CREATE TABLE arbitration_cases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(500) NOT NULL,
    description TEXT,
    case_type VARCHAR(100) NOT NULL,
    dispute_amount DECIMAL(15,2),
    currency VARCHAR(3) DEFAULT 'CNY',
    
    -- 当事人信息
    applicant_id UUID NOT NULL REFERENCES users(id),
    respondent_id UUID REFERENCES users(id),
    respondent_info JSONB, -- 被申请人详细信息（可能未注册）
    
    -- 案件状态
    status case_status_enum DEFAULT 'draft',
    priority priority_enum DEFAULT 'medium', -- 'low', 'medium', 'high', 'urgent'
    
    -- 重要文档
    arbitration_agreement_url TEXT,
    application_form_url TEXT,
    
    -- 时间信息
    submitted_at TIMESTAMP WITH TIME ZONE,
    accepted_at TIMESTAMP WITH TIME ZONE,
    deadline TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    
    -- 费用信息
    arbitration_fee DECIMAL(10,2),
    fee_paid BOOLEAN DEFAULT FALSE,
    fee_paid_at TIMESTAMP WITH TIME ZONE,
    
    -- 元数据
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_cases_case_number ON arbitration_cases(case_number);
CREATE INDEX idx_cases_applicant_id ON arbitration_cases(applicant_id);
CREATE INDEX idx_cases_respondent_id ON arbitration_cases(respondent_id);
CREATE INDEX idx_cases_status ON arbitration_cases(status);
CREATE INDEX idx_cases_created_at ON arbitration_cases(created_at);
CREATE INDEX idx_cases_dispute_amount ON arbitration_cases(dispute_amount);
```

#### case_participants (案件参与人表)
```sql
CREATE TABLE case_participants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID NOT NULL REFERENCES arbitration_cases(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    participant_type participant_type_enum NOT NULL, -- 'applicant', 'respondent', 'arbitrator', 'witness', 'agent'
    role_description VARCHAR(200),
    contact_info JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_case_participants_case_id ON case_participants(case_id);
CREATE INDEX idx_case_participants_user_id ON case_participants(user_id);
CREATE INDEX idx_case_participants_type ON case_participants(participant_type);
```

#### case_documents (案件文档表)
```sql
CREATE TABLE case_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID NOT NULL REFERENCES arbitration_cases(id) ON DELETE CASCADE,
    uploaded_by UUID NOT NULL REFERENCES users(id),
    
    -- 文件信息
    file_name VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL,
    file_size BIGINT NOT NULL,
    file_type VARCHAR(100) NOT NULL,
    mime_type VARCHAR(100),
    file_hash VARCHAR(64), -- SHA-256哈希值
    
    -- 文档分类
    document_type document_type_enum NOT NULL, -- 'application', 'evidence', 'response', 'decision', 'agreement'
    category VARCHAR(100),
    title VARCHAR(500),
    description TEXT,
    
    -- 状态管理
    status document_status_enum DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    review_notes TEXT,
    
    -- 访问控制
    is_public BOOLEAN DEFAULT FALSE,
    access_permissions JSONB,
    
    -- 版本控制
    version INTEGER DEFAULT 1,
    parent_document_id UUID REFERENCES case_documents(id),
    
    -- 元数据
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_case_documents_case_id ON case_documents(case_id);
CREATE INDEX idx_case_documents_uploaded_by ON case_documents(uploaded_by);
CREATE INDEX idx_case_documents_type ON case_documents(document_type);
CREATE INDEX idx_case_documents_status ON case_documents(status);
CREATE INDEX idx_case_documents_created_at ON case_documents(created_at);
```

### 2.3 庭审相关表结构

#### hearing_sessions (庭审会话表)
```sql
CREATE TABLE hearing_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id UUID NOT NULL REFERENCES arbitration_cases(id) ON DELETE CASCADE,
    session_number INTEGER NOT NULL,
    session_type session_type_enum NOT NULL, -- 'arbitration', 'mediation', 'preliminary'
    
    -- 时间安排
    scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
    started_at TIMESTAMP WITH TIME ZONE,
    ended_at TIMESTAMP WITH TIME ZONE,
    duration_minutes INTEGER,
    
    -- 状态管理
    status session_status_enum DEFAULT 'scheduled', -- 'scheduled', 'in_progress', 'completed', 'cancelled'
    
    -- 会议信息
    meeting_room_id VARCHAR(100),
    meeting_url TEXT,
    meeting_password VARCHAR(50),
    
    -- 主持人信息
    presiding_arbitrator_id UUID REFERENCES users(id),
    
    -- 记录信息
    transcript_url TEXT,
    recording_url TEXT,
    
    -- 元数据
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_hearing_sessions_case_id ON hearing_sessions(case_id);
CREATE INDEX idx_hearing_sessions_scheduled_at ON hearing_sessions(scheduled_at);
CREATE INDEX idx_hearing_sessions_status ON hearing_sessions(status);
```

#### hearing_participants (庭审参与者表)
```sql
CREATE TABLE hearing_participants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES hearing_sessions(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id),
    participant_role participant_role_enum NOT NULL, -- 'arbitrator', 'applicant', 'respondent', 'witness', 'observer'
    
    -- 参与状态
    invitation_status invitation_status_enum DEFAULT 'pending', -- 'pending', 'accepted', 'declined'
    attendance_status attendance_status_enum DEFAULT 'absent', -- 'present', 'absent', 'late'
    
    -- 时间记录
    joined_at TIMESTAMP WITH TIME ZONE,
    left_at TIMESTAMP WITH TIME ZONE,
    total_duration_minutes INTEGER,
    
    -- 技术信息
    connection_quality JSONB,
    device_info JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_hearing_participants_session_id ON hearing_participants(session_id);
CREATE INDEX idx_hearing_participants_user_id ON hearing_participants(user_id);
```

### 2.4 调解相关表结构

#### mediations (调解案件表)
```sql
CREATE TABLE mediations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    case_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(500) NOT NULL,
    description TEXT,
    
    -- 关联信息
    related_arbitration_case_id UUID REFERENCES arbitration_cases(id),
    relation_type relation_type_enum, -- 'derived', 'converted', 'independent'
    
    -- 当事人信息
    applicant_id UUID NOT NULL REFERENCES users(id),
    respondent_id UUID REFERENCES users(id),
    mediator_id UUID REFERENCES users(id),
    
    -- 调解状态
    status mediation_status_enum DEFAULT 'pending', -- 'pending', 'in_progress', 'agreement_reached', 'failed', 'completed'
    
    -- 时间信息
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    
    -- 结果信息
    agreement_reached BOOLEAN DEFAULT FALSE,
    agreement_document_id UUID REFERENCES case_documents(id),
    
    -- 元数据
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_mediations_case_number ON mediations(case_number);
CREATE INDEX idx_mediations_applicant_id ON mediations(applicant_id);
CREATE INDEX idx_mediations_mediator_id ON mediations(mediator_id);
CREATE INDEX idx_mediations_status ON mediations(status);
```

### 2.5 消息通知表结构

#### notifications (通知表)
```sql
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- 通知内容
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    notification_type notification_type_enum NOT NULL, -- 'system', 'case_update', 'hearing_reminder', 'document_approval'
    
    -- 关联信息
    related_case_id UUID REFERENCES arbitration_cases(id),
    related_mediation_id UUID REFERENCES mediations(id),
    related_document_id UUID REFERENCES case_documents(id),
    
    -- 状态管理
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP WITH TIME ZONE,
    
    -- 发送渠道
    channels JSONB, -- ['web', 'email', 'sms', 'push']
    sent_channels JSONB,
    
    -- 优先级
    priority priority_enum DEFAULT 'medium',
    
    -- 元数据
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_notifications_type ON notifications(notification_type);
CREATE INDEX idx_notifications_created_at ON notifications(created_at);
```

## 3. 数据库性能优化

### 3.1 索引策略
```sql
-- 复合索引
CREATE INDEX idx_cases_status_created_at ON arbitration_cases(status, created_at);
CREATE INDEX idx_documents_case_type_status ON case_documents(case_id, document_type, status);
CREATE INDEX idx_notifications_user_read_created ON notifications(user_id, is_read, created_at);

-- 部分索引
CREATE INDEX idx_cases_active ON arbitration_cases(id) WHERE status NOT IN ('completed', 'terminated');
CREATE INDEX idx_documents_pending ON case_documents(id) WHERE status = 'pending';

-- 表达式索引
CREATE INDEX idx_users_email_lower ON users(LOWER(email));
CREATE INDEX idx_cases_amount_range ON arbitration_cases(dispute_amount) WHERE dispute_amount > 100000;
```

### 3.2 分区策略
```sql
-- 按时间分区（案件表）
CREATE TABLE arbitration_cases_2024 PARTITION OF arbitration_cases
FOR VALUES FROM ('2024-01-01') TO ('2025-01-01');

CREATE TABLE arbitration_cases_2025 PARTITION OF arbitration_cases
FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');

-- 按哈希分区（文档表）
CREATE TABLE case_documents_p0 PARTITION OF case_documents
FOR VALUES WITH (MODULUS 4, REMAINDER 0);

CREATE TABLE case_documents_p1 PARTITION OF case_documents
FOR VALUES WITH (MODULUS 4, REMAINDER 1);
```

### 3.3 查询优化
```sql
-- 常用查询的物化视图
CREATE MATERIALIZED VIEW case_statistics AS
SELECT 
    status,
    COUNT(*) as case_count,
    AVG(dispute_amount) as avg_amount,
    DATE_TRUNC('month', created_at) as month
FROM arbitration_cases 
GROUP BY status, DATE_TRUNC('month', created_at);

-- 定期刷新
CREATE OR REPLACE FUNCTION refresh_case_statistics()
RETURNS void AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY case_statistics;
END;
$$ LANGUAGE plpgsql;
```

---

*本数据库设计文档基于LegalMind仲裁平台前端原型的业务逻辑分析制定，为后端开发提供完整的数据模型和性能优化指导。*
