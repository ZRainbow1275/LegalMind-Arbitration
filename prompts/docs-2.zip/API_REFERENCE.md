# LegalMind API 参考文档

## 数据同步 API

### DataSyncManager

全局数据同步管理器，提供模块间数据同步功能。

#### 方法

##### `publishCaseEvent(type, caseData, source)`
发布案件相关事件
- **type**: `'created' | 'updated' | 'deleted'`
- **caseData**: 案件数据对象
- **source**: 事件来源模块名称

```typescript
dataSyncManager.publishCaseEvent('created', {
  id: 'case-001',
  title: '合同纠纷案',
  status: 'active'
}, 'cases-module');
```

##### `publishMediationEvent(type, mediationData, source)`
发布调解相关事件
- **type**: `'created' | 'updated' | 'completed'`
- **mediationData**: 调解数据对象
- **source**: 事件来源模块名称

##### `publishHearingEvent(type, hearingData, source)`
发布庭审相关事件
- **type**: `'scheduled' | 'started' | 'completed'`
- **hearingData**: 庭审数据对象
- **source**: 事件来源模块名称

##### `publishDocumentEvent(type, documentData, source)`
发布文档相关事件
- **type**: `'uploaded' | 'signed' | 'approved'`
- **documentData**: 文档数据对象
- **source**: 事件来源模块名称

##### `publishNotificationEvent(type, notificationData, source)`
发布通知相关事件
- **type**: `'created' | 'read'`
- **notificationData**: 通知数据对象
- **source**: 事件来源模块名称

### useModuleSync Hook

模块数据同步Hook，用于组件级别的数据同步。

#### 参数
- **moduleId**: 模块唯一标识符

#### 返回值
```typescript
{
  register: () => void;           // 注册模块
  unregister: () => void;         // 注销模块
  subscribeToEvents: (callback) => () => void;  // 订阅事件
  processPendingEvents: () => SyncEvent[];       // 处理待处理事件
  moduleState: ModuleState | null;              // 模块状态
  updateState: (updates) => void;               // 更新模块状态
}
```

#### 使用示例
```typescript
const moduleSync = useModuleSync('my-module');

useEffect(() => {
  moduleSync.register();
  
  const unsubscribe = moduleSync.subscribeToEvents((event) => {
    // 处理同步事件
    console.log('Received event:', event);
  });
  
  return () => {
    unsubscribe();
    moduleSync.unregister();
  };
}, []);
```

## 状态管理 API

### useAIMessagesStore

AI消息状态管理Store。

#### 状态
```typescript
{
  conversations: Conversation[];      // 对话列表
  currentConversation: Conversation | null;  // 当前对话
  isTyping: boolean;                 // AI是否正在输入
  inputValue: string;                // 输入框值
  selectedFeature: string;           // 选中的功能
}
```

#### 方法
```typescript
{
  addMessage: (message: Message) => void;
  createNewConversation: (feature?: string) => void;
  setCurrentConversation: (conversation: Conversation) => void;
  setIsTyping: (typing: boolean) => void;
  setInputValue: (value: string) => void;
  setSelectedFeature: (feature: string) => void;
  syncWithFloatingAssistant: () => void;
}
```

### useCasesStore

案件状态管理Store。

#### 状态
```typescript
{
  cases: Case[];                     // 案件列表
}
```

#### 方法
```typescript
{
  setCases: (cases: Case[]) => void;
  removeCase: (caseId: string) => void;
  duplicateCase: (caseId: string) => Case | null;
}
```

## 组件 API

### ProcedureTracker

程序跟踪组件API。

#### Props
```typescript
interface ProcedureTrackerProps {
  hearingType: 'arbitration' | 'mediation';
  currentStep?: string;
  onStepChange?: (stepId: string) => void;
  onStepComplete?: (stepId: string, notes?: string) => void;
  isHost?: boolean;
  className?: string;
}
```

#### 事件
- **onStepChange**: 步骤变更时触发
- **onStepComplete**: 步骤完成时触发

### RoleSpecificInterface

角色特定界面组件API。

#### Props
```typescript
interface RoleSpecificInterfaceProps {
  role: 'arbitrator' | 'applicant' | 'respondent' | 'witness' | 'observer';
  hearingType: 'arbitration' | 'mediation';
  isHost?: boolean;
  onAction?: (action: string, data?: any) => void;
  className?: string;
}
```

#### 支持的操作
- **raise-hand**: 举手发言
- **submit-evidence**: 提交证据
- **control-procedure**: 程序控制
- **mute-all**: 全员静音
- **request-speak**: 请求发言
- **view-materials**: 查看材料

### SmartDocumentGenerator

智能文书生成器API。

#### Props
```typescript
interface SmartDocumentGeneratorProps {
  caseId?: string;
  onDocumentGenerated?: (documentId: string, content: string) => void;
  className?: string;
}
```

#### 模板类型
```typescript
type DocumentType = 'complaint' | 'response' | 'application' | 'agreement' | 'decision' | 'notice';
type DocumentCategory = 'arbitration' | 'mediation' | 'judicial';
```

### NotaryInterface

公证处对接组件API。

#### Props
```typescript
interface NotaryInterfaceProps {
  caseId?: string;
  documentId?: string;
  onNotaryComplete?: (notaryId: string) => void;
  className?: string;
}
```

#### 公证类型
```typescript
type NotaryType = 'agreement' | 'signature' | 'document' | 'identity' | 'evidence';
```

### DossierSystem

卷宗管理系统API。

#### Props
```typescript
interface DossierSystemProps {
  mediationId: string;
  onDocumentUpdate?: (documentId: string, status: string) => void;
  className?: string;
}
```

#### 文档状态
```typescript
type DocumentStatus = 'draft' | 'submitted' | 'approved' | 'rejected' | 'archived';
```

### EnhancedCalendar

增强日程组件API。

#### Props
```typescript
interface EnhancedCalendarProps {
  events: CalendarEvent[];
  onEventCreate?: (event: CalendarEvent) => void;
  onEventUpdate?: (event: CalendarEvent) => void;
  onEventDelete?: (eventId: string) => void;
  viewMode?: ViewMode;
  className?: string;
}
```

#### 视图模式
```typescript
type ViewMode = 'month' | 'week' | 'day' | 'list' | 'swimlane' | 'timeline';
```

## 工具函数 API

### 动画工具

#### fadeIn
淡入动画类名
```typescript
const fadeIn: string;
```

#### slideUp
上滑动画类名
```typescript
const slideUp: string;
```

#### scaleIn
缩放动画类名
```typescript
const scaleIn: string;
```

### 会话管理

#### useSessionTimeout
会话超时管理Hook
```typescript
function useSessionTimeout(timeout?: number): void;
```

#### useRole
角色管理Hook
```typescript
function useRole(): {
  currentRole: 'arbitrator' | 'guest' | 'applicant';
  switchRole: (role: string) => void;
  isArbitrator: boolean;
}
```

## 数据类型定义

### SyncEvent
同步事件数据结构
```typescript
interface SyncEvent {
  id: string;
  type: SyncEventType;
  timestamp: Date;
  source: string;
  data: any;
  userId?: string;
  caseId?: string;
  mediationId?: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  processed: boolean;
}
```

### CalendarEvent
日程事件数据结构
```typescript
interface CalendarEvent {
  id: string;
  title: string;
  startTime: Date;
  endTime: Date;
  type: string;
  location?: string;
  participants: string[];
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: string;
  isOnline?: boolean;
}
```

### Message
消息数据结构
```typescript
interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  type?: 'text' | 'file' | 'image';
}
```

### Case
案件数据结构
```typescript
interface Case {
  id: string;
  caseNumber: string;
  title: string;
  status: string;
  type: string;
  amount: number;
  createdAt: Date;
  updatedAt: Date;
  deadline?: Date;
  parties: string[];
  arbitrator?: string;
}
```

---

*最后更新: 2024年2月15日*
